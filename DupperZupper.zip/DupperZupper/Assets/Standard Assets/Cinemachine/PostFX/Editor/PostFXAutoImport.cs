﻿
namespace Cinemachine.PostFX
{
    
    
    
    class PostFXAutoImport
    {
        [UnityEditor.InitializeOnLoad]
        class EditorInitialize 
        {
            static EditorInitialize() 
            {
#if UNITY_POST_PROCESSING_STACK_V2
                
                CinemachinePostProcessing.InitializeModule();
#else
                
                if (Cinemachine.Utility.ReflectionHelpers.TypeIsDefined("UnityEngine.PostProcessing.PostProcessingBehaviour"))
                {
                    if (Cinemachine.Editor.ScriptableObjectUtility.AddDefineForAllBuildTargets("UNITY_POST_PROCESSING_STACK_V1"))
                    {
                        string path = Cinemachine.Editor.ScriptableObjectUtility.CinemachineInstallAssetPath + "/PostFX/CinemachinePostFX.cs";
                        UnityEditor.AssetDatabase.ImportAsset(path, UnityEditor.ImportAssetOptions.ForceUpdate);
                    }
                }
    #if UNITY_POST_PROCESSING_STACK_V1
                
                CinemachinePostFX.InitializeModule(); 
    #endif
#endif
            } 
        }
    }
}
