﻿#if UNITY_POST_PROCESSING_STACK_V2











using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace Cinemachine.PostFX
{
    
    
    
    
    
    
    
    
    
    
    
    [DocumentationSorting(101, DocumentationSortingAttribute.Level.UserRef)]
    [ExecuteInEditMode]
    [AddComponentMenu("")] 
    [SaveDuringPlay]
    public class CinemachinePostProcessing : CinemachineExtension
    {
        [Tooltip("If checked, then the Focus Distance will be set to the distance between the camera and the LookAt target.  Requires DepthOfField effect in the Profile")]
        public bool m_FocusTracksTarget;

        [Tooltip("Offset from target distance, to be used with Focus Tracks Target.  Offsets the sharpest point away from the LookAt target.")]
        public float m_FocusOffset;

        [Tooltip("This Post-Processing profile will be applied whenever this virtual camera is live")]
        public PostProcessProfile m_Profile;

        bool mCachedProfileIsInvalid = true;
        PostProcessProfile mProfileCopy;
        public PostProcessProfile Profile { get { return mProfileCopy != null ? mProfileCopy : m_Profile; } }

        
        public bool IsValid { get { return m_Profile != null && m_Profile.settings.Count > 0; } }

        
        public void InvalidateCachedProfile() { mCachedProfileIsInvalid = true; }

        void CreateProfileCopy()
        {
            DestroyProfileCopy();
            PostProcessProfile profile = ScriptableObject.CreateInstance<PostProcessProfile>();
            if (m_Profile != null)
            {
                foreach (var item in m_Profile.settings)
                {
                    var itemCopy = Instantiate(item);
                    profile.settings.Add(itemCopy);
                }
            }
            mProfileCopy = profile;
            mCachedProfileIsInvalid = false;
        }

        void DestroyProfileCopy()
        {
            if (mProfileCopy != null)
                DestroyImmediate(mProfileCopy);
            mProfileCopy = null;
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            DestroyProfileCopy();
        }

        protected override void PostPipelineStageCallback(
            CinemachineVirtualCameraBase vcam,
            CinemachineCore.Stage stage, ref CameraState state, float deltaTime)
        {
            
            
            
            if (stage == CinemachineCore.Stage.Aim)
            {
                if (!IsValid)
                    DestroyProfileCopy();
                else
                {
                    
                    if (!m_FocusTracksTarget || !state.HasLookAt)
                        DestroyProfileCopy();
                    else
                    {
                        if (mProfileCopy == null || mCachedProfileIsInvalid)
                            CreateProfileCopy();
                        DepthOfField dof;
                        if (mProfileCopy.TryGetSettings(out dof))
                            dof.focusDistance.value 
                                = (state.FinalPosition - state.ReferenceLookAt).magnitude + m_FocusOffset;
                    }

                    
                    state.AddCustomBlendable(new CameraState.CustomBlendable(this, 1));
                }
            }
            
        }

        static void OnCameraCut(CinemachineBrain brain)
        {
            
            PostProcessLayer postFX = brain.PostProcessingComponent as PostProcessLayer;
            if (postFX == null)
                brain.PostProcessingComponent = null;   
            else
                postFX.ResetHistory();
        }

        static void ApplyPostFX(CinemachineBrain brain)
        {
            
            PostProcessLayer ppLayer = brain.GetComponent<PostProcessLayer>();
            if (ppLayer == null || !ppLayer.enabled  || ppLayer.volumeLayer == 0)
                return;

            CameraState state = brain.CurrentCameraState;
            int numBlendables = state.NumCustomBlendables;
            List<PostProcessVolume> volumes = GetDynamicBrainVolumes(brain, ppLayer, numBlendables);
            for (int i = 0; i < volumes.Count; ++i)
            {
                volumes[i].weight = 0;
                volumes[i].sharedProfile = null;
                volumes[i].profile = null;
            }
            for (int i = 0; i < numBlendables; ++i)
            {
                var b = state.GetCustomBlendable(i);
                CinemachinePostProcessing src = b.m_Custom as CinemachinePostProcessing;
                if (!(src == null)) 
                {
                    PostProcessVolume v = volumes[i];
                    v.sharedProfile = src.Profile;
                    v.isGlobal = true;
                    v.priority = float.MaxValue-1;
                    v.weight = b.m_Weight;
                }
            }
            
        }

        static string sVolumeOwnerName = "__CMVolumes";
        static  List<PostProcessVolume> sVolumes = new List<PostProcessVolume>();
        static List<PostProcessVolume> GetDynamicBrainVolumes(
            CinemachineBrain brain, PostProcessLayer ppLayer, int minVolumes)
        {
            
            
            GameObject volumeOwner = null;
            Transform t = brain.transform;
            int numChildren = t.childCount;

            sVolumes.Clear();
            for (int i = 0; volumeOwner == null && i < numChildren; ++i)
            {
                GameObject child = t.GetChild(i).gameObject;
                if (child.hideFlags == HideFlags.HideAndDontSave)
                {
                    child.GetComponents(sVolumes);
                    if (sVolumes.Count > 0)
                        volumeOwner = child;
                }
            }

            if (minVolumes > 0)
            {
                if (volumeOwner == null)
                {
                    volumeOwner = new GameObject(sVolumeOwnerName);
                    volumeOwner.hideFlags = HideFlags.HideAndDontSave;
                    volumeOwner.transform.parent = t;
                }
                
                int mask = ppLayer.volumeLayer.value;
                for (int i = 0; i < 32; ++i)
                {
                    if ((mask & (1 << i)) != 0)
                    {
                        volumeOwner.layer = i;
                        break;
                    }
                }
                while (sVolumes.Count < minVolumes)
                    sVolumes.Add(volumeOwner.gameObject.AddComponent<PostProcessVolume>());
            }
            
            return sVolumes;
        }

        
        [RuntimeInitializeOnLoadMethod]
        public static void InitializeModule()
        {
            
            CinemachineBrain.sPostProcessingHandler.RemoveListener(StaticPostFXHandler);
            CinemachineBrain.sPostProcessingHandler.AddListener(StaticPostFXHandler);
        }

        static void StaticPostFXHandler(CinemachineBrain brain)
        {
            PostProcessLayer postFX = brain.PostProcessingComponent as PostProcessLayer;
            if (postFX == null)
            {
                brain.PostProcessingComponent = brain.GetComponent<PostProcessLayer>();
                postFX = brain.PostProcessingComponent as PostProcessLayer;
                if (postFX != null)
                        brain.m_CameraCutEvent.AddListener(CinemachinePostProcessing.OnCameraCut);
            }
            if (postFX != null)
                CinemachinePostProcessing.ApplyPostFX(brain);
        }
    }
}
#endif
