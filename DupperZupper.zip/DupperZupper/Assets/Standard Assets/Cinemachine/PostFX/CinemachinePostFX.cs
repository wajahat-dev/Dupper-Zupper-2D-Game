﻿using UnityEngine;











namespace Cinemachine.PostFX
{
#if UNITY_POST_PROCESSING_STACK_V1 && !UNITY_POST_PROCESSING_STACK_V2
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    [DocumentationSorting(100, DocumentationSortingAttribute.Level.UserRef)]
    [ExecuteInEditMode]
    [DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/CinemachinePostFX")]
    [SaveDuringPlay]
    public class CinemachinePostFX : MonoBehaviour
    {
        
        void Update() {}

        [Tooltip("When this behaviour is on a Unity Camera, this setting is the default Post-Processing profile for the camera, and will be applied whenever it is not overridden by a virtual camera.  When the behaviour is on a virtual camera, then this is the Post-Processing profile that will become active whenever this virtual camera is live")]
        public UnityEngine.PostProcessing.PostProcessingProfile m_Profile;

        [Tooltip("If checked, then the Focus Distance will be set to the distance between the camera and the LookAt target.")]
        public bool m_FocusTracksTarget;

        [Tooltip("Offset from target distance, to be used with Focus Tracks Target.")]
        public float m_FocusOffset;

        
        CinemachineBrain mBrain;
        UnityEngine.PostProcessing.PostProcessingBehaviour mPostProcessingBehaviour;

        void ConnectToBrain()
        {
            
            
            mBrain = GetComponent<CinemachineBrain>();
            if (mBrain != null)
            {
                mBrain.m_CameraCutEvent.RemoveListener(OnCameraCut);
                mBrain.m_CameraCutEvent.AddListener(OnCameraCut);
            }
            
            mPostProcessingBehaviour = GetComponent<UnityEngine.PostProcessing.PostProcessingBehaviour>();
            if (mPostProcessingBehaviour == null && mBrain != null)
                mPostProcessingBehaviour = gameObject.AddComponent<UnityEngine.PostProcessing.PostProcessingBehaviour>();
        }

        void OnDestroy()
        {
            if (mBrain != null)
                mBrain.m_CameraCutEvent.RemoveListener(OnCameraCut);
        }

        
        internal void PostFXHandler(CinemachineBrain brain)
        {
            
            ICinemachineCamera vcam = brain.ActiveVirtualCamera;
            if (enabled && mBrain != null && mPostProcessingBehaviour != null)
            {
                
                CinemachinePostFX postFX = GetEffectivePostFX(vcam);
                if (postFX == null)
                    postFX = this;  
                if (postFX.m_Profile != null)
                {
                    
                    CameraState state = brain.CurrentCameraState;
                    UnityEngine.PostProcessing.DepthOfFieldModel.Settings dof
                        = postFX.m_Profile.depthOfField.settings;
                    if (postFX.m_FocusTracksTarget && state.HasLookAt)
                        dof.focusDistance = (state.FinalPosition - state.ReferenceLookAt).magnitude
                            + postFX.m_FocusOffset;
                    postFX.m_Profile.depthOfField.settings = dof;
                }
                
                if (mPostProcessingBehaviour.profile != postFX.m_Profile)
                {
                    mPostProcessingBehaviour.profile = postFX.m_Profile;
                    mPostProcessingBehaviour.ResetTemporalEffects();
                }
            }
            
        }

        CinemachinePostFX GetEffectivePostFX(ICinemachineCamera vcam)
        {
            while (vcam != null && vcam.LiveChildOrSelf != vcam)
                vcam = vcam.LiveChildOrSelf;
            CinemachinePostFX postFX = null;
            while (vcam != null && postFX == null)
            {
                CinemachineVirtualCameraBase vcamBase = vcam as CinemachineVirtualCameraBase;
                if (vcamBase != null)
                    postFX = vcamBase.GetComponent<CinemachinePostFX>();
                if (postFX != null && !postFX.enabled)
                    postFX = null;
                vcam = vcam.ParentCamera;
            }
            return postFX;
        }

        void OnCameraCut(CinemachineBrain brain)
        {
            if (mPostProcessingBehaviour != null)
            {
                
                mPostProcessingBehaviour.ResetTemporalEffects();
            }
        }

        static void StaticPostFXHandler(CinemachineBrain brain)
        {
            CinemachinePostFX postFX = brain.PostProcessingComponent as CinemachinePostFX;
            if (postFX == null)
            {
                brain.PostProcessingComponent = brain.GetComponent<CinemachinePostFX>();
                postFX = brain.PostProcessingComponent as CinemachinePostFX;
                if (postFX != null)
                    postFX.ConnectToBrain();
            }
            if (postFX != null)
                postFX.PostFXHandler(brain);
        }

        
        [RuntimeInitializeOnLoadMethod]
        public static void InitializeModule()
        {
            
            CinemachineBrain.sPostProcessingHandler.RemoveListener(StaticPostFXHandler);
            CinemachineBrain.sPostProcessingHandler.AddListener(StaticPostFXHandler);
        }
    }
#endif
}
