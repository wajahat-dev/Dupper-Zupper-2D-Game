using System;
using System.Linq.Expressions;
using UnityEditor;

namespace Cinemachine.Editor
{
    public static class SerializedPropertyHelper
    {
        
        
        
        
        
        
        
        
        
        
        
        public static string PropertyName(Expression<Func<object>> exp)
        {
            var body = exp.Body as MemberExpression;
            if (body == null)
            {
                var ubody = (UnaryExpression)exp.Body;
                body = ubody.Operand as MemberExpression;
            }
            return body.Member.Name;
        }

        
        
        
        
        
        
        
        
        
        public static SerializedProperty FindProperty(this SerializedObject obj, Expression<Func<object>> exp)
        {
            return obj.FindProperty(PropertyName(exp));
        }

        
        
        
        
        
        
        
        
        
        public static SerializedProperty FindPropertyRelative(this SerializedProperty obj, Expression<Func<object>> exp)
        {
            return obj.FindPropertyRelative(PropertyName(exp));
        }
    }
}
