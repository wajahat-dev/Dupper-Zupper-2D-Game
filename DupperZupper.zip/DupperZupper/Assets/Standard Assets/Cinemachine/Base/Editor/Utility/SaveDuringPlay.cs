using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace SaveDuringPlay
{
    
    public static class ObjectTreeUtil
    {
        
        
        
        public static string GetFullName(GameObject current)
        {
            if (current == null)
                return "";
            if (current.transform.parent == null)
                return "/" + current.name;
            return GetFullName(current.transform.parent.gameObject) + "/" + current.name;
        }

        
        
        
        public static GameObject FindObjectFromFullName(string fullName, GameObject[] roots)
        {
            if (fullName == null || fullName.Length == 0 || roots == null)
                return null;

            string[] path = fullName.Split('/');
            if (path.Length < 2)   
                return null;

            Transform root = null;
            for (int i = 0; root == null && i < roots.Length; ++i)
                if (roots[i].name == path[1])
                    root = roots[i].transform;

            if (root == null)
                return null;

            for (int i = 2; i < path.Length; ++i)   
            {
                bool found = false;
                for (int c = 0; c < root.childCount; ++c)
                {
                    Transform child = root.GetChild(c);
                    if (child.name == path[i])
                    {
                        found = true;
                        root = child;
                        break;
                    }
                }
                if (!found)
                    return null;
            }
            return root.gameObject;
        }

        
        public static GameObject[] FindAllRootObjectsInScene() 
        {
            return UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects();
        }


        
        
        
        public static T[] FindAllBehavioursInScene<T>() where T : MonoBehaviour
        {
            List<T> objectsInScene = new List<T>();
            foreach (T b in Resources.FindObjectsOfTypeAll<T>())
            {
                GameObject go = b.gameObject;
                if (go.hideFlags == HideFlags.NotEditable || go.hideFlags == HideFlags.HideAndDontSave)
                    continue;
                if (EditorUtility.IsPersistent(go.transform.root.gameObject))
                    continue;
                objectsInScene.Add(b);
            }
            return objectsInScene.ToArray();
        }
    }

    class GameObjectFieldScanner
    {
        
        
        
        
        public OnLeafFieldDelegate OnLeafField;
        public delegate bool OnLeafFieldDelegate(string fullName, Type type, ref object value);

        
        
        
        
        public OnFieldValueChangedDelegate OnFieldValueChanged;
        public delegate bool OnFieldValueChangedDelegate(
            string fullName, FieldInfo fieldInfo, object fieldOwner, object value);

        
        
        
        public FilterFieldDelegate FilterField;
        public delegate bool FilterFieldDelegate(string fullName, FieldInfo fieldInfo);

        
        
        
        public BindingFlags bindingFlags = BindingFlags.Public | BindingFlags.Instance;

        bool ScanFields(string fullName, Type type, ref object obj)
        {
            bool doneSomething = false;

            
            bool isLeaf = true;
            if (obj != null
                && !type.IsSubclassOf(typeof(Component))
                && !type.IsSubclassOf(typeof(GameObject)))
            {
                
                if (type.IsArray)
                {
                    isLeaf = false;
                    Array array = obj as Array;
                    object arrayLength = array.Length;
                    if (OnLeafField != null && OnLeafField(
                            fullName + ".Length", arrayLength.GetType(), ref arrayLength))
                    {
                        Array newArray = Array.CreateInstance(
                                array.GetType().GetElementType(), Convert.ToInt32(arrayLength));
                        Array.Copy(array, 0, newArray, 0, Math.Min(array.Length, newArray.Length));
                        array = newArray;
                        doneSomething = true;
                    }
                    for (int i = 0; i < array.Length; ++i)
                    {
                        object element = array.GetValue(i);
                        if (ScanFields(fullName + "[" + i + "]", array.GetType().GetElementType(), ref element))
                        {
                            array.SetValue(element, i);
                            doneSomething = true;
                        }
                    }
                    if (doneSomething)
                        obj = array;
                }
                else
                {
                    
                    FieldInfo[] fields = obj.GetType().GetFields(bindingFlags);
                    if (fields.Length > 0)
                    {
                        isLeaf = false;
                        for (int i = 0; i < fields.Length; ++i)
                        {
                            string name = fullName + "." + fields[i].Name;
                            if (FilterField == null || FilterField(name, fields[i]))
                            {
                                object fieldValue = fields[i].GetValue(obj);
                                if (ScanFields(name, fields[i].FieldType, ref fieldValue))
                                {
                                    doneSomething = true;
                                    if (OnFieldValueChanged != null)
                                        OnFieldValueChanged(name, fields[i], obj, fieldValue);
                                }
                            }
                        }
                    }
                }
            }
            
            if (isLeaf && OnLeafField != null)
                if (OnLeafField(fullName, type, ref obj))
                    doneSomething = true;

            return doneSomething;
        }

        public bool ScanFields(string fullName, MonoBehaviour b)
        {
            bool doneSomething = false;
            FieldInfo[] fields = b.GetType().GetFields(bindingFlags);
            if (fields.Length > 0)
            {
                for (int i = 0; i < fields.Length; ++i)
                {
                    string name = fullName + "." + fields[i].Name;
                    if (FilterField == null || FilterField(name, fields[i]))
                    {
                        object fieldValue = fields[i].GetValue(b);
                        if (ScanFields(name, fields[i].FieldType, ref fieldValue))
                            doneSomething = true;

                        
                        if (doneSomething && OnFieldValueChanged != null)
                            OnFieldValueChanged(fullName, fields[i], b, fieldValue);
                    }
                }
            }
            return doneSomething;
        }

        
        
        
        
        public bool ScanFields(GameObject go, string prefix = null)
        {
            bool doneSomething = false;
            if (prefix == null)
                prefix = "";
            else if (prefix.Length > 0)
                prefix += ".";

            MonoBehaviour[] components = go.GetComponents<MonoBehaviour>();
            for (int i = 0; i < components.Length; ++i)
            {
                MonoBehaviour c = components[i];
                if (c != null && ScanFields(prefix + c.GetType().FullName + i, c))
                    doneSomething = true;
            }
            return doneSomething;
        }
    };


    
    
    
    
    
    
    class ObjectStateSaver
    {
        string mObjectFullPath;

        Dictionary<string, string> mValues = new Dictionary<string, string>();

        
        
        
        
        
        public void CollectFieldValues(GameObject go)
        {
            mObjectFullPath = ObjectTreeUtil.GetFullName(go);
            GameObjectFieldScanner scanner = new GameObjectFieldScanner();
            scanner.FilterField = FilterField;
            scanner.OnLeafField = (string fullName, Type type, ref object value) =>
                {
                    
                    mValues[fullName] = StringFromLeafObject(value);
                    
                    return false;
                };
            scanner.ScanFields(go);
        }

        public GameObject FindSavedGameObject(GameObject[] roots) 
        { 
            return ObjectTreeUtil.FindObjectFromFullName(mObjectFullPath, roots);
        }
        public string ObjetFullPath { get { return mObjectFullPath; } }

        
        
        
        
        
        
        
        public bool PutFieldValues(GameObject go, GameObject[] roots)
        {
            GameObjectFieldScanner scanner = new GameObjectFieldScanner();
            scanner.FilterField = FilterField;
            scanner.OnLeafField = (string fullName, Type type, ref object value) =>
                {
                    
                    string savedValue;
                    if (mValues.TryGetValue(fullName, out savedValue)
                        && StringFromLeafObject(value) != savedValue)
                    {
                        
                        value = LeafObjectFromString(type, mValues[fullName].Trim(), roots);
                        return true; 
                    }
                    return false;
                };
            scanner.OnFieldValueChanged = (fullName, fieldInfo, fieldOwner, value) =>
                {
                    fieldInfo.SetValue(fieldOwner, value);
                    return true;
                };
            return scanner.ScanFields(go);
        }

        
        bool FilterField(string fullName, FieldInfo fieldInfo)
        {
            var attrs = fieldInfo.GetCustomAttributes(false);
            foreach (var attr in attrs)
                if (attr.GetType().Name.Contains("NoSaveDuringPlay"))
                    return false;
            return true;
        }

        
        
        
        
        
        
        
        static object LeafObjectFromString(Type type, string value, GameObject[] roots)
        {
            if (type == typeof(Single))
                return float.Parse(value);
            if (type == typeof(Double))
                return double.Parse(value);
            if (type == typeof(Boolean))
                return Boolean.Parse(value);
            if (type == typeof(string))
                return value;
            if (type == typeof(Int32))
                return Int32.Parse(value);
            if (type == typeof(UInt32))
                return UInt32.Parse(value);
            if (type.IsSubclassOf(typeof(Component)))
            {
                
                GameObject go = ObjectTreeUtil.FindObjectFromFullName(value, roots);
                return (go != null) ? go.GetComponent(type) : null;
            }
            if (type.IsSubclassOf(typeof(GameObject)))
            {
                
                return GameObject.Find(value);
            }
            return null;
        }

        static string StringFromLeafObject(object obj)
        {
            if (obj == null)
                return string.Empty;

            if (obj.GetType().IsSubclassOf(typeof(Component)))
            {
                Component c = (Component)obj;
                if (c == null) 
                    return string.Empty;
                return ObjectTreeUtil.GetFullName(c.gameObject);
            }
            if (obj.GetType().IsSubclassOf(typeof(GameObject)))
            {
                GameObject go = (GameObject)obj;
                if (go == null) 
                    return string.Empty;
                return ObjectTreeUtil.GetFullName(go);
            }
            return obj.ToString();
        }
    };


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    [InitializeOnLoad]
    public class SaveDuringPlay
    {
        public static string kEnabledKey = "SaveDuringPlay_Enabled";
        public static bool Enabled
        {
            get { return EditorPrefs.GetBool(kEnabledKey, false); }
            set
            {
                if (value != Enabled)
                {
                    EditorPrefs.SetBool(kEnabledKey, value);
                }
            }
        }

        static SaveDuringPlay()
        {
            
#if UNITY_2017_2_OR_NEWER
            EditorApplication.playModeStateChanged += OnPlayStateChanged;
#else
            EditorApplication.update += OnEditorUpdate;
            EditorApplication.playmodeStateChanged += OnPlayStateChanged;
#endif
        }

#if UNITY_2017_2_OR_NEWER
        static void OnPlayStateChanged(PlayModeStateChange pmsc)
        {
            if (Enabled)
            {
                
                if (pmsc == PlayModeStateChange.ExitingPlayMode)
                    SaveAllInterestingStates();
                else if (pmsc == PlayModeStateChange.EnteredEditMode && sSavedStates != null)
                    RestoreAllInterestingStates();
            }
        }
#else
        static void OnPlayStateChanged()
        {
            
            if (Enabled)
            {
                if (!EditorApplication.isPlayingOrWillChangePlaymode && EditorApplication.isPlaying)
                    SaveAllInterestingStates();
            }
        }

        static float sWaitStartTime = 0;
        static void OnEditorUpdate()
        {
            if (Enabled && sSavedStates != null && !Application.isPlaying)
            {
                
                const float WaitTime = 1f; 
                float time = Time.realtimeSinceStartup;
                if (sWaitStartTime == 0)
                    sWaitStartTime = time;
                else if (time - sWaitStartTime > WaitTime)
                {
                    RestoreAllInterestingStates();
                    sWaitStartTime = 0;
                }
            }
        }
#endif

        
        
        
        public static OnHotSaveDelegate OnHotSave;
        public delegate void OnHotSaveDelegate();

        
        static Transform[] FindInterestingObjects()
        {
            List<Transform> objects = new List<Transform>();
            MonoBehaviour[] everything = ObjectTreeUtil.FindAllBehavioursInScene<MonoBehaviour>();
            foreach (var b in everything)
            {
                var attrs = b.GetType().GetCustomAttributes(true);
                foreach (var attr in attrs)
                {
                    if (attr.GetType().Name.Contains("SaveDuringPlay"))
                    {
                        
                        objects.Add(b.transform);
                        break;
                    }
                }
            }
            return objects.ToArray();
        }

        static List<ObjectStateSaver> sSavedStates = null;
        static GameObject sSaveStatesGameObject;
        static void SaveAllInterestingStates()
        {
            
            if (OnHotSave != null)
                OnHotSave();

            sSavedStates = new List<ObjectStateSaver>();
            Transform[] objects = FindInterestingObjects();
            foreach (Transform obj in objects)
            {
                ObjectStateSaver saver = new ObjectStateSaver();
                saver.CollectFieldValues(obj.gameObject);
                sSavedStates.Add(saver);
            }
            if (sSavedStates.Count == 0)
                sSavedStates = null;
        }

        static void RestoreAllInterestingStates()
        {
            
            bool dirty = false;
            GameObject[] roots = ObjectTreeUtil.FindAllRootObjectsInScene();
            foreach (ObjectStateSaver saver in sSavedStates)
            {
                GameObject go = saver.FindSavedGameObject(roots);
                if (go != null)
                {
                    Undo.RegisterFullObjectHierarchyUndo(go, "SaveDuringPlay");
                    if (saver.PutFieldValues(go, roots))
                    {
                        
                        EditorUtility.SetDirty(go);
                        dirty = true;
                    }
                }
            }
            if (dirty)
                UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
            sSavedStates = null;
        }
    }
}
