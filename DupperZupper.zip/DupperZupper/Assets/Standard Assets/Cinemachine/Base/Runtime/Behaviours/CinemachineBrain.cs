using System;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine.Utility;
using UnityEngine.Events;
using System.Collections;

namespace Cinemachine
{
    
    
    
    
    
    
    
    
    
    
    
    
    
    [DocumentationSorting(0, DocumentationSortingAttribute.Level.UserRef)]

    [ExecuteInEditMode, DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/CinemachineBrain")]
    [SaveDuringPlay]
    public class CinemachineBrain : MonoBehaviour
    {
        
        
        
        [Tooltip("When enabled, the current camera and blend will be indicated in the game window, for debugging")]
        public bool m_ShowDebugText = false;

        
        
        
        [Tooltip("When enabled, the camera's frustum will be shown at all times in the scene view")]
        public bool m_ShowCameraFrustum = true;

        
        
        
        
        [Tooltip("When enabled, the cameras will always respond in real-time to user input and damping, even if the game is running in slow motion")]
        public bool m_IgnoreTimeScale = false;

        
        
        
        
        [Tooltip("If set, this object's Y axis will define the worldspace Up vector for all the virtual cameras.  This is useful for instance in top-down game environments.  If not set, Up is worldspace Y.  Setting this appropriately is important, because Virtual Cameras don't like looking straight up or straight down.")]
        public Transform m_WorldUpOverride;

        
        [DocumentationSorting(0.1f, DocumentationSortingAttribute.Level.UserRef)]
        public enum UpdateMethod
        {
            
            FixedUpdate,
            
            LateUpdate,
            
            SmartUpdate
        };

        
        
        
        
        [Tooltip("Use FixedUpdate if all your targets are animated during FixedUpdate (e.g. RigidBodies), LateUpdate if all your targets are animated during the normal Update loop, and SmartUpdate if you want Cinemachine to do the appropriate thing on a per-target basis.  SmartUpdate is the recommended setting")]
        public UpdateMethod m_UpdateMethod = UpdateMethod.SmartUpdate;

        
        
        
        [CinemachineBlendDefinitionProperty]
        [Tooltip("The blend that is used in cases where you haven't explicitly defined a blend between two Virtual Cameras")]
        public CinemachineBlendDefinition m_DefaultBlend
            = new CinemachineBlendDefinition(CinemachineBlendDefinition.Style.EaseInOut, 2f);

        
        
        
        [Tooltip("This is the asset that contains custom settings for blends between specific virtual cameras in your scene")]
        public CinemachineBlenderSettings m_CustomBlends = null;

        
        
        
        
        public Camera OutputCamera
        {
            get
            {
                if (m_OutputCamera == null)
                    m_OutputCamera = GetComponent<Camera>();
                return m_OutputCamera;
            }
        }
        private Camera m_OutputCamera = null; 

        
        [Serializable] public class BrainEvent : UnityEvent<CinemachineBrain> {}

        
        [Serializable] public class VcamEvent : UnityEvent<ICinemachineCamera> {}

        
        [Tooltip("This event will fire whenever a virtual camera goes live and there is no blend")]
        public BrainEvent m_CameraCutEvent = new BrainEvent();

        
        
        [Tooltip("This event will fire whenever a virtual camera goes live.  If a blend is involved, then the event will fire on the first frame of the blend.")]
        public VcamEvent m_CameraActivatedEvent = new VcamEvent();

        
        internal Component PostProcessingComponent { get; set; }

        
        
        
        
        
        
        
        internal static BrainEvent sPostProcessingHandler = new BrainEvent();

        
        
        
        
        public static ICinemachineCamera SoloCamera { get; set; }

        
        
        public static Color GetSoloGUIColor() { return Color.Lerp(Color.red, Color.yellow, 0.8f); }

        
        public Vector3 DefaultWorldUp
            { get { return (m_WorldUpOverride != null) ? m_WorldUpOverride.transform.up : Vector3.up; } }

        private ICinemachineCamera mActiveCameraPreviousFrame;
        private ICinemachineCamera mOutgoingCameraPreviousFrame;
        private CinemachineBlend mActiveBlend = null;
        private bool mPreviousFrameWasOverride = false;

        private class OverrideStackFrame
        {
            public int id;
            public ICinemachineCamera camera;
            public CinemachineBlend blend;
            public float deltaTime;
            public float timeOfOverride;
            public bool Active { get { return camera != null; } }
            public bool Expired 
            { 
                get 
                { 
                    return !Application.isPlaying 
                        && Time.realtimeSinceStartup - timeOfOverride > Time.maximumDeltaTime; 
                }
            }
        }
        private List<OverrideStackFrame> mOverrideStack = new List<OverrideStackFrame>();
        private int mNextOverrideId = 1;

        
        private OverrideStackFrame GetOverrideFrame(int id)
        {
            int count = mOverrideStack.Count;
            for (int i = 0; i < count; ++i)
                if (mOverrideStack[i].id == id)
                    return mOverrideStack[i];
            OverrideStackFrame ovr = new OverrideStackFrame();
            ovr.id = id;
            mOverrideStack.Insert(0, ovr);
            return ovr;
        }

        
        private OverrideStackFrame mOverrideBlendFromNothing = new OverrideStackFrame();
        private OverrideStackFrame GetNextActiveFrame(int overrideId)
        {
            bool pastMine = false;
            int count = mOverrideStack.Count;
            for (int i = 0; i < count; ++i)
            {
                if (mOverrideStack[i].id == overrideId)
                    pastMine = true;
                else if (mOverrideStack[i].Active && pastMine)
                    return mOverrideStack[i];
            }
            
            mOverrideBlendFromNothing.camera = TopCameraFromPriorityQueue();
            mOverrideBlendFromNothing.blend = mActiveBlend;
            return mOverrideBlendFromNothing;
        }

        
        private OverrideStackFrame GetActiveOverride()
        {
            int count = mOverrideStack.Count;
            for (int i = 0; i < count; ++i)
                if (mOverrideStack[i].Active)
                    return mOverrideStack[i];
            return null;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        internal int SetCameraOverride(
            int overrideId,
            ICinemachineCamera camA, ICinemachineCamera camB,
            float weightB, float deltaTime)
        {
            
            if (overrideId < 0)
                overrideId = mNextOverrideId++;

            OverrideStackFrame ovr = GetOverrideFrame(overrideId);
            ovr.camera = null;
            ovr.deltaTime = deltaTime;
            ovr.timeOfOverride = Time.realtimeSinceStartup;
            if (camA != null || camB != null)
            {
                if (weightB <= Utility.UnityVectorExtensions.Epsilon)
                {
                    ovr.blend = null;
                    if (camA != null)
                        ovr.camera = camA; 
                }
                else if (weightB >= (1f - Utility.UnityVectorExtensions.Epsilon))
                {
                    ovr.blend = null;
                    if (camB != null)
                        ovr.camera = camB; 
                }
                else
                {
                    
                    
                    
                    
                    if (camB == null)
                    {
                        
                        ICinemachineCamera c = camB;
                        camB = camA;
                        camA = c;
                        weightB = 1f - weightB;
                    }

                    
                    if (camA == null)
                    {
                        OverrideStackFrame frame = GetNextActiveFrame(overrideId);
                        if (frame.blend != null)
                            camA = new BlendSourceVirtualCamera(frame.blend, deltaTime);
                        else
                            camA = frame.camera != null ? frame.camera : camB;
                    }

                    
                    if (ovr.blend == null)
                        ovr.blend = new CinemachineBlend(
                            camA, camB, AnimationCurve.Linear(0, 0, 1, 1), 1, weightB);
                    ovr.blend.CamA = camA;
                    ovr.blend.CamB = camB;
                    ovr.blend.TimeInBlend = weightB;
                    ovr.camera = camB;
                }
            }
            
            return overrideId;
        }

        
        
        
        
        
        
        
        internal void ReleaseCameraOverride(int overrideId)
        {
            int count = mOverrideStack.Count;
            for (int i = 0; i < count; ++i)
            {
                if (mOverrideStack[i].id == overrideId)
                {
                    mOverrideStack.RemoveAt(i);
                    return;
                }
            }
        }

        private void OnEnable()
        {
            mActiveBlend = null;
            mActiveCameraPreviousFrame = null;
            mOutgoingCameraPreviousFrame = null;
            mPreviousFrameWasOverride = false;
            CinemachineCore.Instance.AddActiveBrain(this);
        }

        private void OnDisable()
        {
            CinemachineCore.Instance.RemoveActiveBrain(this);
            mActiveBlend = null;
            mActiveCameraPreviousFrame = null;
            mOutgoingCameraPreviousFrame = null;
            mPreviousFrameWasOverride = false;
            mOverrideStack.Clear();
        }

        private void Start()
        {
            UpdateVirtualCameras(CinemachineCore.UpdateFilter.Late, -1f);

            
            StartCoroutine(AfterPhysics());
        }

#if UNITY_EDITOR
        private void OnGUI()
        {
            if (!m_ShowDebugText)
                CinemachineGameWindowDebug.ReleaseScreenPos(this);
            else
            {
                
                Color color = GUI.color;
                ICinemachineCamera vcam = ActiveVirtualCamera;
                string text = "CM " + gameObject.name + ": ";
                if (SoloCamera != null)
                {
                    text += "SOLO ";
                    GUI.color = GetSoloGUIColor();
                }
                if (ActiveBlend == null)
                    text += (vcam != null ? "[" + vcam.Name + "]" : "(none)");
                else
                    text += ActiveBlend.Description;
                Rect r = CinemachineGameWindowDebug.GetScreenPos(this, text, GUI.skin.box);
                GUI.Label(r, text, GUI.skin.box);
                GUI.color = color;
            }
        }
#endif

        WaitForFixedUpdate mWaitForFixedUpdate = new WaitForFixedUpdate();
        private IEnumerator AfterPhysics()
        {
            while (true)
            {
                yield return mWaitForFixedUpdate;
                if (m_UpdateMethod == UpdateMethod.SmartUpdate)
                {
                    AddSubframe(); 
                    UpdateVirtualCameras(CinemachineCore.UpdateFilter.Fixed, GetEffectiveDeltaTime(true));
                }
                else
                {
                    if (m_UpdateMethod == UpdateMethod.LateUpdate)
                        msSubframes = 1;
                    else
                    {
                        AddSubframe(); 
                        UpdateVirtualCameras(CinemachineCore.UpdateFilter.ForcedFixed, GetEffectiveDeltaTime(true));
                    }
                }
            }
        }

        private void LateUpdate()
        {
            float deltaTime = GetEffectiveDeltaTime(false);
            if (m_UpdateMethod == UpdateMethod.SmartUpdate)
                UpdateVirtualCameras(CinemachineCore.UpdateFilter.Late, deltaTime);
            else if (m_UpdateMethod == UpdateMethod.LateUpdate)
                UpdateVirtualCameras(CinemachineCore.UpdateFilter.ForcedLate, deltaTime);

            
            ProcessActiveCamera(GetEffectiveDeltaTime(false));
        }

#if UNITY_EDITOR
        
        
        
        private void OnPreCull()
        {
            if (!Application.isPlaying)
            {
                
                
                float deltaTime = GetEffectiveDeltaTime(false);
                msSubframes = 1;
                UpdateVirtualCameras(CinemachineCore.UpdateFilter.Late, deltaTime);
                ProcessActiveCamera(GetEffectiveDeltaTime(false));
            }
        }

#endif
        private float GetEffectiveDeltaTime(bool fixedDelta)
        {
            if (SoloCamera != null)
                return Time.unscaledDeltaTime;
            OverrideStackFrame activeOverride = GetActiveOverride();
            if (activeOverride != null)
                return activeOverride.Expired ? -1 : activeOverride.deltaTime;
            if (!Application.isPlaying)
                return -1;
            if (m_IgnoreTimeScale)
                return fixedDelta ? Time.fixedDeltaTime : Time.unscaledDeltaTime;
            return fixedDelta ? Time.fixedDeltaTime * Time.timeScale : Time.deltaTime;
        }

        private void UpdateVirtualCameras(CinemachineCore.UpdateFilter updateFilter, float deltaTime)
        {
            
            CinemachineCore.Instance.CurrentUpdateFilter = updateFilter;

            
            CinemachineCore.Instance.UpdateAllActiveVirtualCameras(DefaultWorldUp, deltaTime);

            
            
            ICinemachineCamera vcam = ActiveVirtualCamera;
            if (vcam != null)
                CinemachineCore.Instance.UpdateVirtualCamera(vcam, DefaultWorldUp, deltaTime);
            CinemachineBlend activeBlend = ActiveBlend;
            if (activeBlend != null)
                activeBlend.UpdateCameraState(DefaultWorldUp, deltaTime);

            
            CinemachineCore.Instance.CurrentUpdateFilter = CinemachineCore.UpdateFilter.Late;
            
        }

        private void ProcessActiveCamera(float deltaTime)
        {
            
            if (!isActiveAndEnabled)
            {
                mActiveCameraPreviousFrame = null;
                mOutgoingCameraPreviousFrame = null;
                mPreviousFrameWasOverride = false;
                return;
            }

            

            OverrideStackFrame activeOverride = GetActiveOverride();
            ICinemachineCamera activeCamera = ActiveVirtualCamera;
            if (activeCamera == null)
                mOutgoingCameraPreviousFrame = null;
            else
            {
                
                if (activeOverride != null)
                    mActiveBlend = null;
                CinemachineBlend activeBlend = ActiveBlend;

                
                if (mActiveCameraPreviousFrame != null && mActiveCameraPreviousFrame.VirtualCameraGameObject == null)
                    mActiveCameraPreviousFrame = null;

                
                if (mActiveCameraPreviousFrame != activeCamera)
                {
                    
                    if (mActiveCameraPreviousFrame != null
                        && !mPreviousFrameWasOverride
                        && activeOverride == null
                        && deltaTime >= 0)
                    {
                        
                        float duration = 0;
                        AnimationCurve curve = LookupBlendCurve(
                            mActiveCameraPreviousFrame, activeCamera, out duration);
                        activeBlend = CreateBlend(
                                mActiveCameraPreviousFrame, activeCamera,
                                curve, duration, mActiveBlend);
                    }
                    
                    if (activeCamera != mOutgoingCameraPreviousFrame)
                    {
                        
                        activeCamera.OnTransitionFromCamera(mActiveCameraPreviousFrame, DefaultWorldUp, deltaTime);

                        
                        
                        if (!activeCamera.VirtualCameraGameObject.activeInHierarchy
                            && (activeBlend == null || !activeBlend.Uses(activeCamera)))
                        {
                            activeCamera.UpdateCameraState(DefaultWorldUp, -1);
                        }
                        if (m_CameraActivatedEvent != null)
                            m_CameraActivatedEvent.Invoke(activeCamera);
                    }
                    
                    
                    if (activeBlend == null
                        || (activeBlend.CamA != mActiveCameraPreviousFrame
                            && activeBlend.CamB != mActiveCameraPreviousFrame
                            && activeBlend.CamA != mOutgoingCameraPreviousFrame
                            && activeBlend.CamB != mOutgoingCameraPreviousFrame))
                    {
                        if (m_CameraCutEvent != null)
                            m_CameraCutEvent.Invoke(this);
                    }
                }

                
                if (activeBlend != null)
                {
                    if (activeOverride == null)
                        activeBlend.TimeInBlend += (deltaTime >= 0)
                            ? deltaTime : activeBlend.Duration;
                    if (activeBlend.IsComplete)
                        activeBlend = null;
                }
                if (activeOverride == null)
                    mActiveBlend = activeBlend;

                
                CameraState state = activeCamera.State;
                if (activeBlend != null)
                    state = activeBlend.State;
                PushStateToUnityCamera(state, activeCamera);

                mOutgoingCameraPreviousFrame = null;
                if (activeBlend != null)
                    mOutgoingCameraPreviousFrame = activeBlend.CamB;
            }

            mActiveCameraPreviousFrame = activeCamera;
            mPreviousFrameWasOverride = activeOverride != null;

            if (mPreviousFrameWasOverride)
            {
                
                if (activeOverride.blend != null)
                {
                    if (activeOverride.blend.BlendWeight < 0.5f)
                    {
                        mActiveCameraPreviousFrame = activeOverride.blend.CamA;
                        mOutgoingCameraPreviousFrame = activeOverride.blend.CamB;
                    }
                    else
                    {
                        mActiveCameraPreviousFrame = activeOverride.blend.CamB;
                        mOutgoingCameraPreviousFrame = activeOverride.blend.CamA;
                    }
                }
            }
            
        }

        
        
        
        public bool IsBlending { get { return ActiveBlend != null && ActiveBlend.IsValid; } }

        
        
        
        public CinemachineBlend ActiveBlend
        {
            get
            {
                if (SoloCamera != null)
                    return null;
                OverrideStackFrame ovr = GetActiveOverride();
                return (ovr != null && ovr.blend != null) ? ovr.blend : mActiveBlend;
            }
        }

        
        
        
        
        
        
        
        public bool IsLive(ICinemachineCamera vcam)
        {
            if (IsLiveItself(vcam))
                return true;

            ICinemachineCamera parent = vcam.ParentCamera;
            while (parent != null && parent.IsLiveChild(vcam))
            {
                if (IsLiveItself(parent))
                    return true;
                vcam = parent;
                parent = vcam.ParentCamera;
            }
            return false;
        }

        
        private bool IsLiveItself(ICinemachineCamera vcam)
        {
            if (mActiveCameraPreviousFrame == vcam)
                return true;
            if (ActiveVirtualCamera == vcam)
                return true;
            if (IsBlending && ActiveBlend.Uses(vcam))
                return true;
            return false;
        }

        
        
        
        public ICinemachineCamera ActiveVirtualCamera
        {
            get
            {
                if (SoloCamera != null)
                    return SoloCamera;
                OverrideStackFrame ovr = GetActiveOverride();
                return (ovr != null && ovr.camera != null) 
                    ? ovr.camera : TopCameraFromPriorityQueue();
            }
        }

        
        
        
        public CameraState CurrentCameraState { get; private set; }

        
        
        
        
        private ICinemachineCamera TopCameraFromPriorityQueue()
        {
            Camera outputCamera = OutputCamera;
            int mask = outputCamera == null ? ~0 : outputCamera.cullingMask;
            int numCameras = CinemachineCore.Instance.VirtualCameraCount;
            for (int i = 0; i < numCameras; ++i)
            {
                ICinemachineCamera cam = CinemachineCore.Instance.GetVirtualCamera(i);
                GameObject go = cam != null ? cam.VirtualCameraGameObject : null;
                if (go != null && (mask & (1 << go.layer)) != 0)
                    return cam;
            }
            return null;
        }

        
        
        
        
        
        private AnimationCurve LookupBlendCurve(
            ICinemachineCamera fromKey, ICinemachineCamera toKey, out float duration)
        {
            
            AnimationCurve blendCurve = m_DefaultBlend.BlendCurve;
            if (m_CustomBlends != null)
            {
                string fromCameraName = (fromKey != null) ? fromKey.Name : string.Empty;
                string toCameraName = (toKey != null) ? toKey.Name : string.Empty;
                blendCurve = m_CustomBlends.GetBlendCurveForVirtualCameras(
                        fromCameraName, toCameraName, blendCurve);
            }
            var keys = blendCurve.keys;
            duration = (keys == null || keys.Length == 0) ? 0 : keys[keys.Length-1].time;
            return blendCurve;
        }

        
        
        
        
        private CinemachineBlend CreateBlend(
            ICinemachineCamera camA, ICinemachineCamera camB, 
            AnimationCurve blendCurve, float duration,
            CinemachineBlend activeBlend)
        {
            
            if (blendCurve == null || duration <= 0 || (camA == null && camB == null))
            {
                
                return null;
            }
            if (camA == null || activeBlend != null)
            {
                
                CameraState state = CameraState.Default;
                if (activeBlend != null)
                    state = activeBlend.State;
                else
                {
                    state.RawPosition = transform.position;
                    state.RawOrientation = transform.rotation;
                    state.Lens = LensSettings.FromCamera(OutputCamera);
                }
                camA = new StaticPointVirtualCamera(state, activeBlend == null ? "(none)" : "Mid-blend");
            }
            CinemachineBlend blend = new CinemachineBlend(camA, camB, blendCurve, duration, 0);
            
            return blend;
        }

        
        private void PushStateToUnityCamera(CameraState state, ICinemachineCamera vcam)
        {
            
            CurrentCameraState = state;
            transform.position = state.FinalPosition;
            transform.rotation = state.FinalOrientation;
            Camera cam = OutputCamera;
            if (cam != null)
            {
                cam.fieldOfView = state.Lens.FieldOfView;
                cam.orthographicSize = state.Lens.OrthographicSize;
                cam.nearClipPlane = state.Lens.NearClipPlane;
                cam.farClipPlane = state.Lens.FarClipPlane;
            }
            if (sPostProcessingHandler != null)
                sPostProcessingHandler.Invoke(this);
            
        }

        static int msCurrentFrame;
        static int msFirstBrainObjectId;
        static int msSubframes;
        void AddSubframe()
        {
            int now = Time.frameCount;
            if (now == msCurrentFrame)
            {
                if (msFirstBrainObjectId == GetInstanceID())
                    ++msSubframes;
            }
            else
            {
                msCurrentFrame = now;
                msFirstBrainObjectId = GetInstanceID();
                msSubframes = 1;
            }
        }

        
        
        
        internal static int GetSubframeCount() { return Math.Max(1, msSubframes); }
    }

    
    
    
    
    internal class StaticPointVirtualCamera : ICinemachineCamera
    {
        public StaticPointVirtualCamera(CameraState state, string name) { State = state; Name = name; }
        public void SetState(CameraState state) { State = state; }

        public string Name { get; private set; }
        public string Description { get { return ""; }}
        public int Priority { get; set; }
        public Transform LookAt { get; set; }
        public Transform Follow { get; set; }
        public CameraState State { get; private set; }
        public GameObject VirtualCameraGameObject { get { return null; } }
        public ICinemachineCamera LiveChildOrSelf { get { return this; } }
        public ICinemachineCamera ParentCamera { get { return null; } }
        public bool IsLiveChild(ICinemachineCamera vcam) { return false; }
        public void UpdateCameraState(Vector3 worldUp, float deltaTime) {}
        public void OnTransitionFromCamera(ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime) {}
    }

    
    
    
    
    
    internal class BlendSourceVirtualCamera : ICinemachineCamera
    {
        public BlendSourceVirtualCamera(CinemachineBlend blend, float deltaTime)
        {
            Blend = blend;
            UpdateCameraState(blend.CamA.State.ReferenceUp, deltaTime);
        }

        public CinemachineBlend Blend { get; private set; }

        public string Name { get { return "Blend"; }}
        public string Description { get { return Blend.Description; }}
        public int Priority { get; set; }
        public Transform LookAt { get; set; }
        public Transform Follow { get; set; }
        public CameraState State { get; private set; }
        public GameObject VirtualCameraGameObject { get { return null; } }
        public ICinemachineCamera LiveChildOrSelf { get { return Blend.CamB; } }
        public ICinemachineCamera ParentCamera { get { return null; } }
        public bool IsLiveChild(ICinemachineCamera vcam) { return vcam == Blend.CamA || vcam == Blend.CamB; }
        public CameraState CalculateNewState(float deltaTime) { return State; }
        public void UpdateCameraState(Vector3 worldUp, float deltaTime)
        {
            Blend.UpdateCameraState(worldUp, deltaTime);
            State = Blend.State;
        }
        public void OnTransitionFromCamera(ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime) {}
    }
}
