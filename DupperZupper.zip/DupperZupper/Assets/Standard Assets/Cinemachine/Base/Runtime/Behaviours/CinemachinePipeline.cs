using UnityEngine;

namespace Cinemachine
{
    
    
    
    [AddComponentMenu("")] 
    public sealed class CinemachinePipeline : MonoBehaviour
    {
    }
}
