using System.Collections.Generic;
using UnityEngine;
using Cinemachine.Utility;

namespace Cinemachine
{
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    [DocumentationSorting(12, DocumentationSortingAttribute.Level.UserRef)]
    [ExecuteInEditMode, DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/CinemachineClearShot")]
    public class CinemachineClearShot : CinemachineVirtualCameraBase
    {
        
        [Tooltip("Default object for the camera children to look at (the aim target), if not specified in a child camera.  May be empty if all children specify targets of their own.")]
        [NoSaveDuringPlay]
        public Transform m_LookAt = null;

        
        [Tooltip("Default object for the camera children wants to move with (the body target), if not specified in a child camera.  May be empty if all children specify targets of their own.")]
        [NoSaveDuringPlay]
        public Transform m_Follow = null;

        
        [Tooltip("When enabled, the current child camera and blend will be indicated in the game window, for debugging")]
        [NoSaveDuringPlay]
        public bool m_ShowDebugText = false;

        
        [SerializeField, HideInInspector, NoSaveDuringPlay]
        public CinemachineVirtualCameraBase[] m_ChildCameras = null;

        
        [Tooltip("Wait this many seconds before activating a new child camera")]
        public float m_ActivateAfter;

        
        [Tooltip("An active camera must be active for at least this many seconds")]
        public float m_MinDuration;

        
        [Tooltip("If checked, camera choice will be randomized if multiple cameras are equally desirable.  Otherwise, child list order and child camera priority will be used.")]
        public bool m_RandomizeChoice = false;

        
        [CinemachineBlendDefinitionProperty]
        [Tooltip("The blend which is used if you don't explicitly define a blend between two Virtual Cameras")]
        public CinemachineBlendDefinition m_DefaultBlend
            = new CinemachineBlendDefinition(CinemachineBlendDefinition.Style.Cut, 0);

        
        [HideInInspector]
        public CinemachineBlenderSettings m_CustomBlends = null;

        
        public override string Description 
        { 
            get 
            { 
                
                ICinemachineCamera vcam = LiveChild;
                if (mActiveBlend == null) 
                    return (vcam != null) ? "[" + vcam.Name + "]" : "(none)";
                return mActiveBlend.Description;
            }
        }
        
        
        
        public ICinemachineCamera LiveChild { set; get; }

        
        public override CameraState State { get { return m_State; } }

        
        public override ICinemachineCamera LiveChildOrSelf { get { return LiveChild; } }

        
        
        
        public override bool IsLiveChild(ICinemachineCamera vcam) 
        { 
            return vcam == LiveChild 
                || (mActiveBlend != null && (vcam == mActiveBlend.CamA || vcam == mActiveBlend.CamB));
        }

        
        
        override public Transform LookAt
        {
            get { return ResolveLookAt(m_LookAt); }
            set { m_LookAt = value; }
        }

        
        
        override public Transform Follow
        {
            get { return ResolveFollow(m_Follow); }
            set { m_Follow = value; }
        }

        
        
        
        public override void RemovePostPipelineStageHook(OnPostPipelineStageDelegate d)
        {
            base.RemovePostPipelineStageHook(d);
            UpdateListOfChildren();
            foreach (var vcam in m_ChildCameras)
                vcam.RemovePostPipelineStageHook(d);
        }

        
        
        
        
        
        public override void UpdateCameraState(Vector3 worldUp, float deltaTime)
        {
            
            if (!PreviousStateIsValid)
                deltaTime = -1;

            
            UpdateListOfChildren();
            ICinemachineCamera previousCam = LiveChild;
            LiveChild = ChooseCurrentCamera(worldUp, deltaTime);

            
            if (previousCam != null && LiveChild != null && previousCam != LiveChild)
            {
                
                float duration = 0;
                AnimationCurve curve = LookupBlendCurve(previousCam, LiveChild, out duration);
                mActiveBlend = CreateBlend(
                        previousCam, LiveChild,
                        curve, duration, mActiveBlend, deltaTime);

                
                LiveChild.OnTransitionFromCamera(previousCam, worldUp, deltaTime);

                
                CinemachineCore.Instance.GenerateCameraActivationEvent(LiveChild);

                
                if (mActiveBlend == null)
                    CinemachineCore.Instance.GenerateCameraCutEvent(LiveChild);
            }

            
            if (mActiveBlend != null)
            {
                mActiveBlend.TimeInBlend += (deltaTime >= 0)
                    ? deltaTime : mActiveBlend.Duration;
                if (mActiveBlend.IsComplete)
                    mActiveBlend = null;
            }

            if (mActiveBlend != null)
            {
                mActiveBlend.UpdateCameraState(worldUp, deltaTime);
                m_State =  mActiveBlend.State;
            }
            else if (LiveChild != null)
                m_State =  LiveChild.State;

            PreviousStateIsValid = true;
            
        }

        
        protected override void OnEnable()
        {
            base.OnEnable();
            InvalidateListOfChildren();
            mActiveBlend = null;
        }

        
        public void OnTransformChildrenChanged()
        {
            InvalidateListOfChildren();
        }

#if UNITY_EDITOR
        
        protected override void OnGUI()
        {
            base.OnGUI();
            if (!m_ShowDebugText)
                CinemachineGameWindowDebug.ReleaseScreenPos(this);
            else
            {
                string text = Name + ": " + Description;
                Rect r = CinemachineGameWindowDebug.GetScreenPos(this, text, GUI.skin.box);
                GUI.Label(r, text, GUI.skin.box);
            }
        }
#endif
        
        public bool IsBlending { get { return mActiveBlend != null; } }

        CameraState m_State = CameraState.Default;

        
        public CinemachineVirtualCameraBase[] ChildCameras
        { 
            get { UpdateListOfChildren(); return m_ChildCameras; }
        }

        float mActivationTime = 0;
        float mPendingActivationTime = 0;
        ICinemachineCamera mPendingCamera;
        private CinemachineBlend mActiveBlend = null;

        void InvalidateListOfChildren()
        { 
            m_ChildCameras = null; 
            m_RandomizedChilden = null; 
            LiveChild = null; 
        }

        
        
        public void ResetRandomization()
        {
            m_RandomizedChilden = null;
            mRandomizeNow = true; 
        }
        
        void UpdateListOfChildren()
        {
            if (m_ChildCameras != null)
                return;

            List<CinemachineVirtualCameraBase> list = new List<CinemachineVirtualCameraBase>();
            CinemachineVirtualCameraBase[] kids = GetComponentsInChildren<CinemachineVirtualCameraBase>(true);
            foreach (CinemachineVirtualCameraBase k in kids)
                if (k.transform.parent == transform)
                    list.Add(k);
            m_ChildCameras = list.ToArray();

            
            mActivationTime = mPendingActivationTime = 0;
            mPendingCamera = null;
            LiveChild = null;
            mActiveBlend = null;
        }

        private bool mRandomizeNow = false;
        private  CinemachineVirtualCameraBase[] m_RandomizedChilden = null;

        private ICinemachineCamera ChooseCurrentCamera(Vector3 worldUp, float deltaTime)
        {
            if (m_ChildCameras == null || m_ChildCameras.Length == 0)
            {
                mActivationTime = 0;
                return null;
            }

            CinemachineVirtualCameraBase[] childCameras = m_ChildCameras;
            if (!m_RandomizeChoice)
                m_RandomizedChilden = null;
            else if (m_ChildCameras.Length > 1)
            {
                if (m_RandomizedChilden == null)
                    m_RandomizedChilden = Randomize(m_ChildCameras);
                childCameras = m_RandomizedChilden;
            }

            if (LiveChild != null && !LiveChild.VirtualCameraGameObject.activeSelf)
                LiveChild = null;
            ICinemachineCamera best = LiveChild;
            for (int i = 0; i < childCameras.Length; ++i)
            {
                CinemachineVirtualCameraBase vcam = childCameras[i];
                if (vcam != null && vcam.VirtualCameraGameObject.activeInHierarchy)
                {
                    
                    if (best == null 
                        || vcam.State.ShotQuality > best.State.ShotQuality
                        || (vcam.State.ShotQuality == best.State.ShotQuality && vcam.Priority > best.Priority)
                        || (m_RandomizeChoice && mRandomizeNow && (ICinemachineCamera)vcam != LiveChild 
                            && vcam.State.ShotQuality == best.State.ShotQuality 
                            && vcam.Priority == best.Priority))
                    {
                        best = vcam;
                    }
                }
            }
            mRandomizeNow = false;

            float now = Time.time;
            if (mActivationTime != 0)
            {
                
                if (LiveChild == best)
                {
                    
                    mPendingActivationTime = 0;
                    mPendingCamera = null;
                    return best;
                }

                
                if (deltaTime >= 0)
                {
                    if (mPendingActivationTime != 0 && mPendingCamera == best)
                    {
                        
                        
                        if ((now - mPendingActivationTime) > m_ActivateAfter
                            && (now - mActivationTime) > m_MinDuration)
                        {
                            
                            m_RandomizedChilden = null; 
                            mActivationTime = now;
                            mPendingActivationTime = 0;
                            mPendingCamera = null;
                            return best;
                        }
                        return LiveChild;
                    }
                }
            }
            
            mPendingActivationTime = 0; 
            mPendingCamera = null;

            
            if (deltaTime >= 0 && mActivationTime > 0)
            {
                if (m_ActivateAfter > 0
                    || (now - mActivationTime) < m_MinDuration)
                {
                    
                    mPendingCamera = best;
                    mPendingActivationTime = now;
                    return LiveChild;
                }
            }
            
            m_RandomizedChilden = null; 
            mActivationTime = now;
            return best;
        }

        struct Pair { public int a; public float b; }
        CinemachineVirtualCameraBase[] Randomize(CinemachineVirtualCameraBase[] src)
        {
            List<Pair> pairs = new List<Pair>();
            for (int i = 0; i < src.Length; ++i)
            {
                Pair p = new Pair(); p.a = i; p.b = Random.Range(0, 1000f);
                pairs.Add(p);
            }
            pairs.Sort((p1, p2) => (int)p1.b - (int)p2.b);
            CinemachineVirtualCameraBase[] dst = new CinemachineVirtualCameraBase[src.Length];
            Pair[] result = pairs.ToArray();
            for (int i = 0; i < src.Length; ++i)
                dst[i] = src[result[i].a];
            return dst;
        }

        private AnimationCurve LookupBlendCurve(
            ICinemachineCamera fromKey, ICinemachineCamera toKey, out float duration)
        {
            
            AnimationCurve blendCurve = m_DefaultBlend.BlendCurve;
            if (m_CustomBlends != null)
            {
                string fromCameraName = (fromKey != null) ? fromKey.Name : string.Empty;
                string toCameraName = (toKey != null) ? toKey.Name : string.Empty;
                blendCurve = m_CustomBlends.GetBlendCurveForVirtualCameras(
                        fromCameraName, toCameraName, blendCurve);
            }
            var keys = blendCurve.keys;
            duration = (keys == null || keys.Length == 0) ? 0 : keys[keys.Length-1].time;
            return blendCurve;
        }

        private CinemachineBlend CreateBlend(
            ICinemachineCamera camA, ICinemachineCamera camB, 
            AnimationCurve blendCurve, float duration,
            CinemachineBlend activeBlend, float deltaTime)
        {
            if (blendCurve == null || duration <= 0 || (camA == null && camB == null))
                return null;

            if (camA == null || activeBlend != null)
            {
                
                CameraState state = (activeBlend != null) ? activeBlend.State : State;
                camA = new StaticPointVirtualCamera(state, (activeBlend != null) ? "Mid-blend" : "(none)");
            }
            return new CinemachineBlend(camA, camB, blendCurve, duration, 0);
        }

        
        
        
        
        
        public override void OnTransitionFromCamera(
            ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime) 
        {
            base.OnTransitionFromCamera(fromCam, worldUp, deltaTime);
            if (m_RandomizeChoice && mActiveBlend == null)
            {
                m_RandomizedChilden = null;
                LiveChild = null;
                UpdateCameraState(worldUp, deltaTime);
            }
        }
    }
}
