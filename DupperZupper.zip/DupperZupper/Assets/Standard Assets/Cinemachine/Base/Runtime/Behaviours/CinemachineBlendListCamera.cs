using Cinemachine.Utility;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Cinemachine
{
    
    
    
    
    
    
    
    [DocumentationSorting(13, DocumentationSortingAttribute.Level.UserRef)]
    [ExecuteInEditMode, DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/CinemachineBlendListCamera")]
    public class CinemachineBlendListCamera : CinemachineVirtualCameraBase
    {
        
        [Tooltip("Default object for the camera children to look at (the aim target), if not specified in a child camera.  May be empty if all of the children define targets of their own.")]
        [NoSaveDuringPlay]
        public Transform m_LookAt = null;

        
        [Tooltip("Default object for the camera children wants to move with (the body target), if not specified in a child camera.  May be empty if all of the children define targets of their own.")]
        [NoSaveDuringPlay]
        public Transform m_Follow = null;

        
        [Tooltip("When enabled, the current child camera and blend will be indicated in the game window, for debugging")]
        public bool m_ShowDebugText = false;

        
        [Tooltip("Force all child cameras to be enabled.  This is useful if animating them in Timeline, but consumes extra resources")]
        public bool m_EnableAllChildCameras;

        
        [SerializeField][HideInInspector][NoSaveDuringPlay]
        public CinemachineVirtualCameraBase[] m_ChildCameras = null;

        
        [Serializable]
        public struct Instruction
        {
            
            [Tooltip("The virtual camera to activate when this instruction becomes active")]
            public CinemachineVirtualCameraBase m_VirtualCamera;
            
            [Tooltip("How long to wait (in seconds) before activating the next virtual camera in the list (if any)")]
            public float m_Hold;
            
            [CinemachineBlendDefinitionProperty]
            [Tooltip("How to blend to the next virtual camera in the list (if any)")]
            public CinemachineBlendDefinition m_Blend;
        };

        
        
        [Tooltip("The set of instructions for enabling child cameras.")]
        public Instruction[] m_Instructions;

        
        public override string Description 
        { 
            get 
            { 
                
                ICinemachineCamera vcam = LiveChild;
                if (mActiveBlend == null) 
                    return (vcam != null) ? "[" + vcam.Name + "]": "(none)";
                return mActiveBlend.Description;
            }
        }

        
        
        public ICinemachineCamera LiveChild { set; get; }

        
        public override ICinemachineCamera LiveChildOrSelf { get { return LiveChild; } }

        
        
        
        public override bool IsLiveChild(ICinemachineCamera vcam) 
        { 
            return vcam == LiveChild 
                || (mActiveBlend != null && (vcam == mActiveBlend.CamA || vcam == mActiveBlend.CamB));
        }

        
        public override CameraState State { get { return m_State; } }

        
        
        override public Transform LookAt
        {
            get { return ResolveLookAt(m_LookAt); }
            set { m_LookAt = value; }
        }

        
        
        override public Transform Follow
        {
            get { return ResolveFollow(m_Follow); }
            set { m_Follow = value; }
        }

        
        
        
        public override void RemovePostPipelineStageHook(OnPostPipelineStageDelegate d)
        {
            base.RemovePostPipelineStageHook(d);
            UpdateListOfChildren();
            foreach (var vcam in m_ChildCameras)
                vcam.RemovePostPipelineStageHook(d);
        }

        
        
        
        
        public override void OnTransitionFromCamera(
            ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime) 
        {
            base.OnTransitionFromCamera(fromCam, worldUp, deltaTime);
            mActivationTime = Time.time;
            mCurrentInstruction = -1;
            LiveChild = null;
            mActiveBlend = null;
            UpdateCameraState(worldUp, deltaTime);
        }

        
        
        
        
        
        public override void UpdateCameraState(Vector3 worldUp, float deltaTime)
        {
            
            if (!PreviousStateIsValid)
                deltaTime = -1;

            UpdateListOfChildren();

            AdvanceCurrentInstruction();
            CinemachineVirtualCameraBase best = null;
            if (mCurrentInstruction >= 0 && mCurrentInstruction < m_Instructions.Length)
                best = m_Instructions[mCurrentInstruction].m_VirtualCamera;

            if (m_ChildCameras != null)
            {
                for (int i = 0; i < m_ChildCameras.Length; ++i)
                {
                    CinemachineVirtualCameraBase vcam  = m_ChildCameras[i];
                    if (vcam != null)
                    {
                        bool enableChild = m_EnableAllChildCameras || vcam == best;
                        if (enableChild != vcam.VirtualCameraGameObject.activeInHierarchy)
                        {
                            vcam.gameObject.SetActive(enableChild);
                            if (enableChild)
                                CinemachineCore.Instance.UpdateVirtualCamera(vcam, worldUp, deltaTime);
                        }
                    }
                }
            }

            if (best != null)
            {
                ICinemachineCamera previousCam = LiveChild;
                LiveChild = best;

                
                if (previousCam != null && LiveChild != null && previousCam != LiveChild && mCurrentInstruction > 0)
                {
                    
                    mActiveBlend = CreateBlend(
                            previousCam, LiveChild,
                            m_Instructions[mCurrentInstruction].m_Blend.BlendCurve, 
                            m_Instructions[mCurrentInstruction].m_Blend.m_Time, mActiveBlend, deltaTime);

                    
                    LiveChild.OnTransitionFromCamera(previousCam, worldUp, deltaTime);

                    
                    CinemachineCore.Instance.GenerateCameraActivationEvent(LiveChild);

                    
                    if (mActiveBlend == null)
                        CinemachineCore.Instance.GenerateCameraCutEvent(LiveChild);
                }
            }

            
            if (mActiveBlend != null)
            {
                mActiveBlend.TimeInBlend += (deltaTime >= 0) ? deltaTime : mActiveBlend.Duration;
                if (mActiveBlend.IsComplete)
                    mActiveBlend = null;
            }

            if (mActiveBlend != null)
            {
                mActiveBlend.UpdateCameraState(worldUp, deltaTime);
                m_State = mActiveBlend.State;
            }
            else if (LiveChild != null)
                m_State =  LiveChild.State;

            PreviousStateIsValid = true;
            
        }

        
        protected override void OnEnable()
        {
            base.OnEnable();
            InvalidateListOfChildren();
            mActiveBlend = null;
        }

        
        public void OnTransformChildrenChanged()
        {
            InvalidateListOfChildren();
        }

#if UNITY_EDITOR
        
        protected override void OnGUI()
        {
            base.OnGUI();
            if (!m_ShowDebugText)
                CinemachineGameWindowDebug.ReleaseScreenPos(this);
            else
            {
                string text = Name + ": " + Description;
                Rect r = CinemachineGameWindowDebug.GetScreenPos(this, text, GUI.skin.box);
                GUI.Label(r, text, GUI.skin.box);
            }
        }
#endif
        CameraState m_State = CameraState.Default;

        
        public CinemachineVirtualCameraBase[] ChildCameras { get { UpdateListOfChildren(); return m_ChildCameras; }}

        
        public bool IsBlending { get { return mActiveBlend != null; } }

        
        float mActivationTime = -1;
        int mCurrentInstruction = 0;
        private CinemachineBlend mActiveBlend = null;

        void InvalidateListOfChildren() { m_ChildCameras = null; LiveChild = null; }

        void UpdateListOfChildren()
        {
            if (m_ChildCameras != null)
                return;
            List<CinemachineVirtualCameraBase> list = new List<CinemachineVirtualCameraBase>();
            CinemachineVirtualCameraBase[] kids = GetComponentsInChildren<CinemachineVirtualCameraBase>(true);
            foreach (CinemachineVirtualCameraBase k in kids)
                if (k.transform.parent == transform)
                    list.Add(k);
            m_ChildCameras = list.ToArray();
            ValidateInstructions();
        }

        
        
        public void ValidateInstructions()
        {
            if (m_Instructions == null)
                m_Instructions = new Instruction[0];
            for (int i = 0; i < m_Instructions.Length; ++i)
            {
                if (m_Instructions[i].m_VirtualCamera != null
                    && m_Instructions[i].m_VirtualCamera.transform.parent != transform)
                {
                    m_Instructions[i].m_VirtualCamera = null;
                }
            }
            mActiveBlend = null;
        }

        private void AdvanceCurrentInstruction()
        {
            
            if (m_ChildCameras == null || m_ChildCameras.Length == 0 
                || mActivationTime < 0 || m_Instructions.Length == 0)
            {
                mActivationTime = -1;
                mCurrentInstruction = -1;
                mActiveBlend = null;
            }
            else if (mCurrentInstruction >= m_Instructions.Length - 1)
            {
                mCurrentInstruction = m_Instructions.Length - 1;
            }
            else 
            {
                float now = Time.time;
                if (mCurrentInstruction < 0)
                {
                    mActivationTime = now;
                    mCurrentInstruction = 0;
                }
                else if (now - mActivationTime > Mathf.Max(0, m_Instructions[mCurrentInstruction].m_Hold))
                {
                    mActivationTime = now;
                    ++mCurrentInstruction;
                }
            }
            
        }

        private CinemachineBlend CreateBlend(
            ICinemachineCamera camA, ICinemachineCamera camB, 
            AnimationCurve blendCurve, float duration,
            CinemachineBlend activeBlend, float deltaTime)
        {
            if (blendCurve == null || duration <= 0 || (camA == null && camB == null))
                return null;

            if (camA == null || activeBlend != null)
            {
                
                CameraState state = (activeBlend != null) ? activeBlend.State : State;
                camA = new StaticPointVirtualCamera(state, (activeBlend != null) ? "Mid-blend" : "(none)");
            }
            return new CinemachineBlend(camA, camB, blendCurve,duration,  0);
        }
    }
}
