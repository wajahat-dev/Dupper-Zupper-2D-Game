﻿using UnityEngine;
using Cinemachine.Utility;
using System.Collections.Generic;

namespace Cinemachine
{
    
    
    
    
    
    
    
    
    [DocumentationSorting(20, DocumentationSortingAttribute.Level.UserRef)]
    [ExecuteInEditMode, DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/CinemachineMixingCamera")]
    public class CinemachineMixingCamera : CinemachineVirtualCameraBase
    {
        
        
        
        
        
        public const int MaxCameras = 8;

        
        [Tooltip("The weight of the first tracked camera")]
        public float m_Weight0 = 0.5f;
        
        [Tooltip("The weight of the second tracked camera")]
        public float m_Weight1 = 0.5f;
        
        [Tooltip("The weight of the third tracked camera")]
        public float m_Weight2 = 0.5f;
        
        [Tooltip("The weight of the fourth tracked camera")]
        public float m_Weight3 = 0.5f;
        
        [Tooltip("The weight of the fifth tracked camera")]
        public float m_Weight4 = 0.5f;
        
        [Tooltip("The weight of the sixth tracked camera")]
        public float m_Weight5 = 0.5f;
        
        [Tooltip("The weight of the seventh tracked camera")]
        public float m_Weight6 = 0.5f;
        
        [Tooltip("The weight of the eighth tracked camera")]
        public float m_Weight7 = 0.5f;

        
        
        
        
        public float GetWeight(int index)
        {
            switch (index)
            {
                case 0: return m_Weight0;
                case 1: return m_Weight1;
                case 2: return m_Weight2;
                case 3: return m_Weight3;
                case 4: return m_Weight4;
                case 5: return m_Weight5;
                case 6: return m_Weight6;
                case 7: return m_Weight7;
            }
            Debug.LogError("CinemachineMixingCamera: Invalid index: " + index);
            return 0;
        }

        
        
        
        
        public void SetWeight(int index, float w)
        {
            switch (index)
            {
                case 0: m_Weight0 = w; return;
                case 1: m_Weight1 = w; return;
                case 2: m_Weight2 = w; return;
                case 3: m_Weight3 = w; return;
                case 4: m_Weight4 = w; return;
                case 5: m_Weight5 = w; return;
                case 6: m_Weight6 = w; return;
                case 7: m_Weight7 = w; return;
            }
            Debug.LogError("CinemachineMixingCamera: Invalid index: " + index);
        }

        
        
        
        public float GetWeight(CinemachineVirtualCameraBase vcam)
        {
            int index;
            if (m_indexMap.TryGetValue(vcam, out index))
                return GetWeight(index);
            Debug.LogError("CinemachineMixingCamera: Invalid child: " 
                + ((vcam != null) ? vcam.Name : "(null)"));
            return 0;
        }

        
        
        
        public void SetWeight(CinemachineVirtualCameraBase vcam, float w)
        {
            int index;
            if (m_indexMap.TryGetValue(vcam, out index))
                SetWeight(index, w);
            else
                Debug.LogError("CinemachineMixingCamera: Invalid child: " 
                    + ((vcam != null) ? vcam.Name : "(null)"));
        }

        
        private CameraState m_State = CameraState.Default;

        
        
        private ICinemachineCamera LiveChild { set; get; }

        
        public override CameraState State { get { return m_State; } }

        
        override public Transform LookAt { get; set; }

        
        override public Transform Follow { get; set; }

        
        public override ICinemachineCamera LiveChildOrSelf { get { return LiveChild; } }

        
        
        
        public override void RemovePostPipelineStageHook(OnPostPipelineStageDelegate d)
        {
            base.RemovePostPipelineStageHook(d);
            ValidateListOfChildren();
            foreach (var vcam in m_ChildCameras)
                vcam.RemovePostPipelineStageHook(d);
        }

        
        protected override void OnEnable()
        {
            base.OnEnable();
            InvalidateListOfChildren();
        }

        
        public void OnTransformChildrenChanged()
        {
            InvalidateListOfChildren();
        }

        
        protected override void OnValidate()
        {
            base.OnValidate();
            for (int i = 0; i < MaxCameras; ++i)
                SetWeight(i, Mathf.Max(0, GetWeight(i)));
        }
        
        
        
        
        public override bool IsLiveChild(ICinemachineCamera vcam) 
        { 
            CinemachineVirtualCameraBase[] children = ChildCameras;
            for (int i = 0; i < MaxCameras && i < children.Length; ++i)
                if ((ICinemachineCamera)children[i] == vcam)
                    return GetWeight(i) > UnityVectorExtensions.Epsilon && children[i].isActiveAndEnabled;
            return false;
        }

        private CinemachineVirtualCameraBase[] m_ChildCameras;
        private Dictionary<CinemachineVirtualCameraBase, int> m_indexMap;

        
        
        
        
        public CinemachineVirtualCameraBase[] ChildCameras
        { 
            get { ValidateListOfChildren(); return m_ChildCameras; }
        }

        
        protected void InvalidateListOfChildren() 
        { 
            m_ChildCameras = null; 
            m_indexMap = null;
            LiveChild = null; 
        }

        
        protected void ValidateListOfChildren()
        {
            if (m_ChildCameras != null)
                return;

            m_indexMap = new Dictionary<CinemachineVirtualCameraBase, int>();
            List<CinemachineVirtualCameraBase> list = new List<CinemachineVirtualCameraBase>();
            CinemachineVirtualCameraBase[] kids 
                = GetComponentsInChildren<CinemachineVirtualCameraBase>(true);
            foreach (CinemachineVirtualCameraBase k in kids)
            {
                if (k.transform.parent == transform)
                {
                    int index = list.Count;
                    list.Add(k);
                    if (index < MaxCameras)
                        m_indexMap.Add(k, index);
                }
            }
            m_ChildCameras = list.ToArray();
        }

        
        
        
        
        
        public override void UpdateCameraState(Vector3 worldUp, float deltaTime)
        {
            
            CinemachineVirtualCameraBase[] children = ChildCameras;
            LiveChild = null;
            float highestWeight = 0;
            float totalWeight = 0;
            for (int i = 0; i < MaxCameras && i < children.Length; ++i)
            {
                CinemachineVirtualCameraBase vcam = children[i];
                if (vcam.isActiveAndEnabled)
                {
                    float weight = Mathf.Max(0, GetWeight(i));
                    if (weight > UnityVectorExtensions.Epsilon)
                    {
                        totalWeight += weight;
                        if (totalWeight == weight)
                            m_State = vcam.State;
                        else
                            m_State = CameraState.Lerp(m_State, vcam.State, weight / totalWeight);

                        if (weight > highestWeight)
                        {
                            highestWeight = weight;
                            LiveChild = vcam;
                        }
                    }
                }
            }
            
        }
    }
}
