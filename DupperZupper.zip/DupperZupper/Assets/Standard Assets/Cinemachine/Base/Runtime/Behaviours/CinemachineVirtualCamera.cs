﻿using Cinemachine.Utility;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

namespace Cinemachine
{
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    [DocumentationSorting(1, DocumentationSortingAttribute.Level.UserRef)]
    [ExecuteInEditMode, DisallowMultipleComponent]
    [AddComponentMenu("Cinemachine/CinemachineVirtualCamera")]
    public class CinemachineVirtualCamera : CinemachineVirtualCameraBase
    {
        
        
        
        
        
        [Tooltip("The object that the camera wants to look at (the Aim target).  If this is null, then the vcam's Transform orientation will define the camera's orientation.")]
        [NoSaveDuringPlay]
        public Transform m_LookAt = null;

        
        
        
        
        
        [Tooltip("The object that the camera wants to move with (the Body target).  If this is null, then the vcam's Transform position will define the camera's position.")]
        [NoSaveDuringPlay]
        public Transform m_Follow = null;

        
        
        [FormerlySerializedAs("m_LensAttributes")]
        [Tooltip("Specifies the lens properties of this Virtual Camera.  This generally mirrors the Unity Camera's lens settings, and will be used to drive the Unity camera when the vcam is active.")]
        [LensSettingsProperty]
        public LensSettings m_Lens = LensSettings.Default;

        
        
        
        
        
        
        public const string PipelineName = "cm";

        
        
        override public CameraState State { get { return m_State; } }

        
        
        
        override public Transform LookAt
        {
            get { return ResolveLookAt(m_LookAt); }
            set { m_LookAt = value; }
        }

        
        
        
        override public Transform Follow
        {
            get { return ResolveFollow(m_Follow); }
            set { m_Follow = value; }
        }

        
        
        
        override public void UpdateCameraState(Vector3 worldUp, float deltaTime)
        {
            
            if (!PreviousStateIsValid)
                deltaTime = -1;

            
            if (deltaTime < 0)
                m_State = PullStateFromVirtualCamera(worldUp); 

            
            m_State = CalculateNewState(worldUp, deltaTime);

            
            
            if (!UserIsDragging)
            {
                if (Follow != null)
                    transform.position = State.RawPosition;
                if (LookAt != null)
                    transform.rotation = State.RawOrientation;
            }
            PreviousStateIsValid = true;
            
        }

        
        override protected void OnEnable()
        {
            base.OnEnable();
            InvalidateComponentPipeline();

            
            if (ValidatingStreamVersion < 20170927)
            {
                if (Follow != null && GetCinemachineComponent(CinemachineCore.Stage.Body) == null)
                    AddCinemachineComponent<CinemachineHardLockToTarget>();
                if (LookAt != null && GetCinemachineComponent(CinemachineCore.Stage.Aim) == null)
                    AddCinemachineComponent<CinemachineHardLookAt>();
            }
        }

        
        
        protected override void OnDestroy()
        {
            
            foreach (Transform child in transform)
                if (child.GetComponent<CinemachinePipeline>() != null)
                    child.gameObject.hideFlags
                        &= ~(HideFlags.HideInHierarchy | HideFlags.HideInInspector);

            base.OnDestroy();
        }

        
        protected override void OnValidate()
        {
            base.OnValidate();
            m_Lens.Validate();
        }

        void OnTransformChildrenChanged()
        {
            InvalidateComponentPipeline();
        }

        void Reset()
        {
            DestroyPipeline();
        }

        
        
        
        
        
        public static CreatePipelineDelegate CreatePipelineOverride;

        
        
        
        
        
        
        public delegate Transform CreatePipelineDelegate(
            CinemachineVirtualCamera vcam, string name, CinemachineComponentBase[] copyFrom);

        
        
        
        
        public static DestroyPipelineDelegate DestroyPipelineOverride;

        
        
        
        
        public delegate void DestroyPipelineDelegate(GameObject pipeline);

        
        private void DestroyPipeline()
        {
            List<Transform> oldPipeline = new List<Transform>();
            foreach (Transform child in transform)
                if (child.GetComponent<CinemachinePipeline>() != null)
                    oldPipeline.Add(child);
            
            foreach (Transform child in oldPipeline)
            {
                if (DestroyPipelineOverride != null)
                    DestroyPipelineOverride(child.gameObject);
                else
                    Destroy(child.gameObject);
            }
            m_ComponentOwner = null;
            PreviousStateIsValid = false;
        }

        
        private Transform CreatePipeline(CinemachineVirtualCamera copyFrom)
        {
            CinemachineComponentBase[] components = null;
            if (copyFrom != null)
            {
                copyFrom.InvalidateComponentPipeline(); 
                components = copyFrom.GetComponentPipeline();
            }

            Transform newPipeline = null;
            if (CreatePipelineOverride != null)
                newPipeline = CreatePipelineOverride(this, PipelineName, components);
            else
            {
                GameObject go =  new GameObject(PipelineName);
                go.transform.parent = transform;
                go.AddComponent<CinemachinePipeline>();
                newPipeline = go.transform;

                
                if (components != null)
                    foreach (Component c in components)
                        ReflectionHelpers.CopyFields(c, go.AddComponent(c.GetType()));
            }
            PreviousStateIsValid = false;
            return newPipeline;
        }

        
        
        
        
        public void InvalidateComponentPipeline() { m_ComponentPipeline = null; }

        
        public Transform GetComponentOwner() { UpdateComponentPipeline(); return m_ComponentOwner; }

        
        
        public CinemachineComponentBase[] GetComponentPipeline() { UpdateComponentPipeline(); return m_ComponentPipeline; }

        
        
        
        public CinemachineComponentBase GetCinemachineComponent(CinemachineCore.Stage stage)
        {
            CinemachineComponentBase[] components = GetComponentPipeline();
            if (components != null)
                foreach (var c in components)
                    if (c.Stage == stage)
                        return c;
            return null;
        }

        
        public T GetCinemachineComponent<T>() where T : CinemachineComponentBase
        {
            CinemachineComponentBase[] components = GetComponentPipeline();
            if (components != null)
                foreach (var c in components)
                    if (c is T)
                        return c as T;
            return null;
        }

        
        public T AddCinemachineComponent<T>() where T : CinemachineComponentBase
        {
            
            Transform owner = GetComponentOwner();
            CinemachineComponentBase[] components = owner.GetComponents<CinemachineComponentBase>();

            T component = owner.gameObject.AddComponent<T>();
            if (component != null && components != null)
            {
                
                CinemachineCore.Stage stage = component.Stage;
                for (int i = components.Length - 1; i >= 0; --i)
                {
                    if (components[i].Stage == stage)
                    {
                        components[i].enabled = false;
                        DestroyImmediate(components[i]);
                    }
                }
            }
            InvalidateComponentPipeline();
            return component;
        }

        
        public void DestroyCinemachineComponent<T>() where T : CinemachineComponentBase
        {
            CinemachineComponentBase[] components = GetComponentPipeline();
            if (components != null)
            {
                foreach (var c in components)
                {
                    if (c is T)
                    {
                        c.enabled = false;
                        DestroyImmediate(c);
                        InvalidateComponentPipeline();
                    }
                }
            }
        }

        
        public bool UserIsDragging { get; set; }

        
        public void OnPositionDragged(Vector3 delta)
        {
            CinemachineComponentBase[] components = GetComponentPipeline();
            if (components != null)
                for (int i = 0; i < components.Length; ++i)
                    components[i].OnPositionDragged(delta);
        }

        CameraState m_State = CameraState.Default; 

        CinemachineComponentBase[] m_ComponentPipeline = null;
        [SerializeField][HideInInspector] private Transform m_ComponentOwner = null;   
        void UpdateComponentPipeline()
        {
            
            if (m_ComponentOwner != null && m_ComponentOwner.parent != transform)
            {
                CinemachineVirtualCamera copyFrom = (m_ComponentOwner.parent != null)
                    ? m_ComponentOwner.parent.gameObject.GetComponent<CinemachineVirtualCamera>() : null;
                DestroyPipeline();
                m_ComponentOwner = CreatePipeline(copyFrom);
            }

            
            if (m_ComponentOwner != null && m_ComponentPipeline != null)
                return;

            m_ComponentOwner = null;
            List<CinemachineComponentBase> list = new List<CinemachineComponentBase>();
            foreach (Transform child in transform)
            {
                if (child.GetComponent<CinemachinePipeline>() != null)
                {
                    m_ComponentOwner = child;
                    CinemachineComponentBase[] components = child.GetComponents<CinemachineComponentBase>();
                    foreach (CinemachineComponentBase c in components)
                        list.Add(c);
                }
            }

            
            if (m_ComponentOwner == null)
                m_ComponentOwner = CreatePipeline(null);

            
            if (CinemachineCore.sShowHiddenObjects)
                m_ComponentOwner.gameObject.hideFlags
                    &= ~(HideFlags.HideInHierarchy | HideFlags.HideInInspector);
            else
                m_ComponentOwner.gameObject.hideFlags
                    |= (HideFlags.HideInHierarchy | HideFlags.HideInInspector);

            
            list.Sort((c1, c2) => (int)c1.Stage - (int)c2.Stage);
            m_ComponentPipeline = list.ToArray();
        }

        private CameraState CalculateNewState(Vector3 worldUp, float deltaTime)
        {
            
            CameraState state = PullStateFromVirtualCamera(worldUp);

            if (LookAt != null)
                state.ReferenceLookAt = LookAt.position;

            
            CinemachineCore.Stage curStage = CinemachineCore.Stage.Body;
            UpdateComponentPipeline(); 
            if (m_ComponentPipeline != null)
            {
                for (int i = 0; i < m_ComponentPipeline.Length; ++i)
                    m_ComponentPipeline[i].PrePipelineMutateCameraState(ref state);

                for (int i = 0; i < m_ComponentPipeline.Length; ++i)
                {
                    curStage = AdvancePipelineStage(
                        ref state, deltaTime, curStage, (int)m_ComponentPipeline[i].Stage);
                    m_ComponentPipeline[i].MutateCameraState(ref state, deltaTime);
                }
            }
            int numStages = 3; 
            AdvancePipelineStage(ref state, deltaTime, curStage, numStages);
            return state;
        }

        private CinemachineCore.Stage AdvancePipelineStage(
            ref CameraState state, float deltaTime,
            CinemachineCore.Stage curStage, int maxStage)
        {
            while ((int)curStage < maxStage)
            {
                InvokePostPipelineStageCallback(this, curStage, ref state, deltaTime);
                ++curStage;
            }
            return curStage;
        }

        private CameraState PullStateFromVirtualCamera(Vector3 worldUp)
        {
            CameraState state = CameraState.Default;
            state.RawPosition = transform.position;
            state.RawOrientation = transform.rotation;
            state.ReferenceUp = worldUp;

            CinemachineBrain brain = CinemachineCore.Instance.FindPotentialTargetBrain(this);
            m_Lens.Aspect = brain != null ? brain.OutputCamera.aspect : 1;
            m_Lens.Orthographic = brain != null ? brain.OutputCamera.orthographic : false;
            state.Lens = m_Lens;

            return state;
        }

        
        internal void SetStateRawPosition(Vector3 pos) { m_State.RawPosition = pos; }
    }
}
