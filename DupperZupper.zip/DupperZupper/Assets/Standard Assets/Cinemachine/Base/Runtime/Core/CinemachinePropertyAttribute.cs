using UnityEngine;

namespace Cinemachine
{
    
    
    
    public sealed class LensSettingsPropertyAttribute : PropertyAttribute
    {
    }
    
    
    
    
    public sealed class CinemachineBlendDefinitionPropertyAttribute : PropertyAttribute
    {
    }

    
    
    
    
    
    
    public sealed class SaveDuringPlayAttribute : System.Attribute
    {
    }

    
    
    
    
    public sealed class NoSaveDuringPlayAttribute : PropertyAttribute
    {
    }

    
    public sealed class TagFieldAttribute : PropertyAttribute
    {
    }

    
    
    
    [DocumentationSorting(0f, DocumentationSortingAttribute.Level.Undoc)]
    public sealed class DocumentationSortingAttribute : System.Attribute
    {
        
        public enum Level 
        { 
            
            Undoc, 
            
            API, 
            
            UserRef 
        };
        
        public float SortOrder { get; private set; }
        
        public Level Category { get; private set; }

        
        public DocumentationSortingAttribute(float sortOrder, Level category)
        {
            SortOrder = sortOrder;
            Category = category;
        }
    }
}
