using UnityEngine;

namespace Cinemachine
{
    
    
    
    [DocumentationSorting(24, DocumentationSortingAttribute.Level.API)]
    public abstract class CinemachineComponentBase : MonoBehaviour
    {
        
        protected const float Epsilon = Utility.UnityVectorExtensions.Epsilon;

        
        public CinemachineVirtualCameraBase VirtualCamera 
        { 
            get
            {
                if (m_vcamOwner == null)
                    m_vcamOwner = gameObject.transform.parent.gameObject.GetComponent<CinemachineVirtualCameraBase>();
                return m_vcamOwner;
            }
        }
        CinemachineVirtualCameraBase m_vcamOwner;

        
        public Transform FollowTarget 
        {
            get 
            {
                CinemachineVirtualCameraBase vcam = VirtualCamera;
                return vcam == null ? null : vcam.Follow;
            }
        }

        
        public Transform LookAtTarget 
        {
            get 
            {
                CinemachineVirtualCameraBase vcam = VirtualCamera;
                return vcam == null ? null : vcam.LookAt;
            }
        }

        
        public CameraState VcamState
        {
            get
            {
                CinemachineVirtualCameraBase vcam = VirtualCamera;
                return vcam == null ? CameraState.Default : vcam.State;
            }
        }

        
        public abstract bool IsValid { get; }

        
        
        
        public virtual void PrePipelineMutateCameraState(ref CameraState state) {}

        
        public abstract CinemachineCore.Stage Stage { get; }

        
        
        
        public abstract void MutateCameraState(ref CameraState curState, float deltaTime);

        
        
        
        public virtual void OnPositionDragged(Vector3 delta) {}
    }
}
