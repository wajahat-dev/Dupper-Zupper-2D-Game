using UnityEngine;
using Cinemachine.Utility;
using System;

namespace Cinemachine
{
    
    
    public abstract class CinemachinePathBase : MonoBehaviour
    {
        
        [Tooltip("Path samples per waypoint.  This is used for calculating path distances.")]
        [Range(1, 100)]
        public int m_Resolution = 20;

        
        
        [DocumentationSorting(18.1f, DocumentationSortingAttribute.Level.UserRef)]
        [Serializable] public class Appearance
        {
            [Tooltip("The color of the path itself when it is active in the editor")]
            public Color pathColor = Color.green;
            [Tooltip("The color of the path itself when it is inactive in the editor")]
            public Color inactivePathColor = Color.gray;
            [Tooltip("The width of the railroad-tracks that are drawn to represent the path")]
            [Range(0f, 10f)]
            public float width = 0.2f;
        }
        
        
        [Tooltip("The settings that control how the path will appear in the editor scene view.")]
        public Appearance m_Appearance = new Appearance();

        
        public abstract float MinPos { get; }

        
        public abstract float MaxPos { get; }

        
        public abstract bool Looped { get; }

        
        
        
        public virtual float NormalizePos(float pos)
        {
            if (MaxPos == 0)
                return 0;
            if (Looped)
            {
                pos = pos % MaxPos;
                if (pos < 0)
                    pos += MaxPos;
                return pos;
            }
            return Mathf.Clamp(pos, 0, MaxPos);
        }

        
        
        
        public abstract Vector3 EvaluatePosition(float pos);

        
        
        
        
        public abstract Vector3 EvaluateTangent(float pos);

        
        
        
        public abstract Quaternion EvaluateOrientation(float pos);

        
        
        
        
        
        
        
        
        
        
        
        
        
        public virtual float FindClosestPoint(
            Vector3 p, int startSegment, int searchRadius, int stepsPerSegment)
        {
            float start = MinPos;
            float end = MaxPos;
            if (searchRadius >= 0)
            {
                int r = Mathf.FloorToInt(Mathf.Min(searchRadius, (end - start) / 2f));
                start = startSegment - r;
                end = startSegment + r + 1;
                if (!Looped)
                {
                    start = Mathf.Max(start, MinPos);
                    end = Mathf.Max(end, MaxPos);
                }
            }
            stepsPerSegment = Mathf.RoundToInt(Mathf.Clamp(stepsPerSegment, 1f, 100f));
            float stepSize = 1f / stepsPerSegment;
            float bestPos = startSegment;
            float bestDistance = float.MaxValue;
            int iterations = (stepsPerSegment == 1) ? 1 : 3;
            for (int i = 0; i < iterations; ++i)
            {
                Vector3 v0 = EvaluatePosition(start);
                for (float f = start + stepSize; f <= end; f += stepSize)
                {
                    Vector3 v = EvaluatePosition(f);
                    float t = p.ClosestPointOnSegment(v0, v);
                    float d = Vector3.SqrMagnitude(p - Vector3.Lerp(v0, v, t));
                    if (d < bestDistance)
                    {
                        bestDistance = d;
                        bestPos = f - (1 - t) * stepSize;
                    }
                    v0 = v;
                }
                start = bestPos - stepSize;
                end = bestPos + stepSize;
                stepSize /= stepsPerSegment;
            }
            return bestPos;
        }

        
        public enum PositionUnits
        {
            
            PathUnits,
            
            
            Distance
        }

        
        
        
        public float MinUnit(PositionUnits units)
        { 
            return units == PositionUnits.Distance ? 0 : MinPos; 
        }

        
        
        
        public float MaxUnit(PositionUnits units)
        { 
            return units == PositionUnits.Distance ? PathLength : MaxPos; 
        }

        
        
        
        
        public virtual float NormalizeUnit(float pos, PositionUnits units)
        {
            if (units == PositionUnits.Distance)
                return NormalizePathDistance(pos);
            return NormalizePos(pos);
        }

        
        
        
        
        public Vector3 EvaluatePositionAtUnit(float pos, PositionUnits units)
        {
            if (units == PositionUnits.Distance)
                pos = GetPathPositionFromDistance(pos);
            return EvaluatePosition(pos);
        }

        
        
        
        
        
        public Vector3 EvaluateTangentAtUnit(float pos, PositionUnits units)
        {
            if (units == PositionUnits.Distance)
                pos = GetPathPositionFromDistance(pos);
            return EvaluateTangent(pos);
        }

        
        
        
        
        public Quaternion EvaluateOrientationAtUnit(float pos, PositionUnits units)
        {
            if (units == PositionUnits.Distance)
                pos = GetPathPositionFromDistance(pos);
            return EvaluateOrientation(pos);
        }

        
        
        public abstract int DistanceCacheSampleStepsPerSegment { get; }

        
        
        public virtual void InvalidateDistanceCache() 
        { 
            m_DistanceToPos = null; 
            m_PosToDistance = null; 
            m_CachedSampleSteps = 0;
            m_PathLength = 0; 
        }

        
        
        
        
        
        public bool DistanceCacheIsValid()
        {
            return (MaxPos == MinPos)
                || (m_DistanceToPos != null && m_PosToDistance != null
                    && m_CachedSampleSteps == DistanceCacheSampleStepsPerSegment 
                    && m_CachedSampleSteps > 0);
        }

        
        
        
        
        public float PathLength
        { 
            get 
            {
                if (DistanceCacheSampleStepsPerSegment < 1)
                    return 0;
                if (!DistanceCacheIsValid())
                    ResamplePath(DistanceCacheSampleStepsPerSegment);
                return m_PathLength;
            }
        }

        
        
        
        
        
        public float NormalizePathDistance(float distance)
        {
            float length = PathLength;
            if (length < Vector3.kEpsilon)
                return 0;
            if (Looped)
            {
                distance = distance % length;
                if (distance < 0)
                    distance += length;
            }
            return Mathf.Clamp(distance, 0, length);
        }

        
        
        
        
        public float GetPathPositionFromDistance(float distance)
        {
            if (DistanceCacheSampleStepsPerSegment < 1 || PathLength < UnityVectorExtensions.Epsilon)
                return MinPos;
            distance = NormalizePathDistance(distance);
            float d = distance / m_cachedDistanceStepSize;
            int i = Mathf.FloorToInt(d);
            if (i >= m_DistanceToPos.Length-1)
                return MaxPos;
            float t = d - (float)i;
            return MinPos + Mathf.Lerp(m_DistanceToPos[i], m_DistanceToPos[i+1], t);
        }

        
        
        
        
        public float GetPathDistanceFromPosition(float pos)
        {
            if (DistanceCacheSampleStepsPerSegment < 1 || PathLength < UnityVectorExtensions.Epsilon)
                return 0;
            pos = NormalizePos(pos);
            float d = pos / m_cachedPosStepSize;
            int i = Mathf.FloorToInt(d);
            if (i >= m_PosToDistance.Length-1)
                return m_PathLength;
            float t = d - (float)i;
            return Mathf.Lerp(m_PosToDistance[i], m_PosToDistance[i+1], t);
        }

        private float[] m_DistanceToPos;
        private float[] m_PosToDistance;
        private int m_CachedSampleSteps;
        private float m_PathLength;
        private float m_cachedPosStepSize;
        private float m_cachedDistanceStepSize;

        private void ResamplePath(int stepsPerSegment)
        {
            InvalidateDistanceCache();

            float minPos = MinPos;
            float maxPos = MaxPos;
            float stepSize = 1f / Mathf.Max(1, stepsPerSegment);

            
            int numKeys = Mathf.RoundToInt((maxPos - minPos) / stepSize) + 1;
            m_PosToDistance = new float[numKeys];
            m_CachedSampleSteps = stepsPerSegment;
            m_cachedPosStepSize = stepSize;

            Vector3 p0 = EvaluatePosition(0);
            m_PosToDistance[0] = 0;
            float pos = minPos;
            for (int i = 1; i < numKeys; ++i)
            {
                pos += stepSize;
                Vector3 p = EvaluatePosition(pos);
                float d = Vector3.Distance(p0, p);
                m_PathLength += d;
                p0 = p;
                m_PosToDistance[i] = m_PathLength;
            }

            
            m_DistanceToPos = new float[numKeys];
            m_DistanceToPos[0] = 0;
            if (numKeys > 1)
            {
                stepSize = m_PathLength / (numKeys - 1);
                m_cachedDistanceStepSize = stepSize;
                float distance = 0;
                int posIndex = 1;
                for (int i = 1; i < numKeys; ++i)
                {
                    distance += stepSize;
                    float d = m_PosToDistance[posIndex];
                    while (d < distance && posIndex < numKeys-1)
                         d = m_PosToDistance[++posIndex];
                    float d0 =  m_PosToDistance[posIndex-1];
                    float delta = d - d0;
                    float t = (distance - d0) / delta;
                    m_DistanceToPos[i] = m_cachedPosStepSize * (t + posIndex - 1);
                }
            }
        }
    }
}
