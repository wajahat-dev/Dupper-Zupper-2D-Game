using System;
using UnityEngine;

namespace Cinemachine
{
    
    
    
    
    public class CinemachineBlend
    {
        
        public ICinemachineCamera CamA { get; set; }

        
        public ICinemachineCamera CamB { get; set; }

        
        
        
        public AnimationCurve BlendCurve { get; set; }

        
        public float TimeInBlend { get; set; }

        
        
        
        public float BlendWeight
        { 
            get { return BlendCurve != null ? BlendCurve.Evaluate(TimeInBlend) : 0; } 
        }

        
        public bool IsValid
        {
            get { return (CamA != null || CamB != null); }
        }

        
        
        public float Duration { get; set; }

        
        
        public bool IsComplete { get { return TimeInBlend >= Duration; } }

        
        public string Description
        {
            get
            {
                string fromName = (CamA != null) ? "[" + CamA.Name + "]": "(none)";
                string toName = (CamB != null) ? "[" + CamB.Name + "]" : "(none)";
                int percent = (int)(BlendWeight * 100f);
                return string.Format("{0} {1}% from {2}", toName, percent, fromName);
            }
        }

        
        
        
        public bool Uses(ICinemachineCamera cam)
        {
            if (cam == CamA || cam == CamB)
                return true;
            BlendSourceVirtualCamera b = CamA as BlendSourceVirtualCamera;
            if (b != null && b.Blend.Uses(cam))
                return true;
            b = CamB as BlendSourceVirtualCamera;
            if (b != null && b.Blend.Uses(cam))
                return true;
            return false;
        }

        
        
        
        
        
        public CinemachineBlend(
            ICinemachineCamera a, ICinemachineCamera b, AnimationCurve curve, float duration, float t)
        {
            if (a == null || b == null)
                throw new ArgumentException("Blend cameras cannot be null");
            CamA = a;
            CamB = b;
            BlendCurve = curve;
            TimeInBlend = t;
            Duration = duration;
        }

        
        
        
        public void UpdateCameraState(Vector3 worldUp, float deltaTime)
        {
            
            
            
            CinemachineCore.Instance.UpdateVirtualCamera(CamA, worldUp, deltaTime);
            CinemachineCore.Instance.UpdateVirtualCamera(CamB, worldUp, deltaTime);
        }

        
        public CameraState State { get { return CameraState.Lerp(CamA.State, CamB.State, BlendWeight); } }
    }

    
    
    [Serializable]
    [DocumentationSorting(10.2f, DocumentationSortingAttribute.Level.UserRef)]
    public struct CinemachineBlendDefinition
    {
        
        [DocumentationSorting(10.21f, DocumentationSortingAttribute.Level.UserRef)]
        public enum Style
        {
            
            Cut,
            
            EaseInOut,
            
            EaseIn,
            
            EaseOut,
            
            HardIn,
            
            HardOut,
            
            Linear
        };

        
        [Tooltip("Shape of the blend curve")]
        public Style m_Style;

        
        [Tooltip("Duration of the blend, in seconds")]
        public float m_Time;

        
        
        
        public CinemachineBlendDefinition(Style style, float time)
        {
            m_Style = style;
            m_Time = time;
        }

        
        
        
        
        
        
        public AnimationCurve BlendCurve
        {
            get
            {
                float time = Mathf.Max(0, m_Time);
                switch (m_Style)
                {
                    default:
                    case Style.Cut: return new AnimationCurve();
                    case Style.EaseInOut: return AnimationCurve.EaseInOut(0f, 0f, time, 1f);
                    case Style.EaseIn:
                    {
                        AnimationCurve curve = AnimationCurve.Linear(0f, 0f, time, 1f);
                        Keyframe[] keys = curve.keys;
                        keys[1].inTangent = 0;
                        curve.keys = keys;
                        return curve;
                    }
                    case Style.EaseOut:
                    {
                        AnimationCurve curve = AnimationCurve.Linear(0f, 0f, time, 1f);
                        Keyframe[] keys = curve.keys;
                        keys[0].outTangent = 0;
                        curve.keys = keys;
                        return curve;
                    }
                    case Style.HardIn:
                    {
                        AnimationCurve curve = AnimationCurve.Linear(0f, 0f, time, 1f);
                        Keyframe[] keys = curve.keys;
                        keys[0].outTangent = 0;
                        keys[1].inTangent = 1.5708f; 
                        curve.keys = keys;
                        return curve;
                    }
                    case Style.HardOut:
                    {
                        AnimationCurve curve = AnimationCurve.Linear(0f, 0f, time, 1f);
                        Keyframe[] keys = curve.keys;
                        keys[0].outTangent = 1.5708f; 
                        keys[1].inTangent = 0;
                        curve.keys = keys;
                        return curve;
                    }
                    case Style.Linear: return AnimationCurve.Linear(0f, 0f, time, 1f);
                }
            }
        }
    }
}
