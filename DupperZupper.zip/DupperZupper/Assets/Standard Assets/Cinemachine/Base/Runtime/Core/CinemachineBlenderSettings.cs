using UnityEngine;
using System;

namespace Cinemachine
{
    
    
    
    [DocumentationSorting(10, DocumentationSortingAttribute.Level.UserRef)]
    [Serializable]
    public sealed class CinemachineBlenderSettings : ScriptableObject
    {
        
        
        
        
        [DocumentationSorting(10.1f, DocumentationSortingAttribute.Level.UserRef)]
        [Serializable]
        public struct CustomBlend
        {
            [Tooltip("When blending from this camera")]
            public string m_From;

            [Tooltip("When blending to this camera")]
            public string m_To;

            [Tooltip("Blend curve definition")]
            public CinemachineBlendDefinition m_Blend;
        }
        
        [Tooltip("The array containing explicitly defined blends between two Virtual Cameras")]
        public CustomBlend[] m_CustomBlends = null;

        
        public const string kBlendFromAnyCameraLabel = "**ANY CAMERA**";

        
        
        
        
        
        
        
        
        
        
        public AnimationCurve GetBlendCurveForVirtualCameras(
            string fromCameraName, string toCameraName, AnimationCurve defaultCurve)
        {
            AnimationCurve anyToMe = null;
            AnimationCurve meToAny = null;
            if (m_CustomBlends != null)
            {
                for (int i = 0; i < m_CustomBlends.Length; ++i)
                {
                    
                    CustomBlend blendParams = m_CustomBlends[i];
                    if ((blendParams.m_From == fromCameraName)
                        && (blendParams.m_To == toCameraName))
                    {
                        return blendParams.m_Blend.BlendCurve;
                    }
                    
                    if (blendParams.m_From == kBlendFromAnyCameraLabel)
                    {
                        if (!string.IsNullOrEmpty(toCameraName)
                            && blendParams.m_To == toCameraName)
                        {
                            anyToMe = blendParams.m_Blend.BlendCurve;
                        }
                        else if (blendParams.m_To == kBlendFromAnyCameraLabel)
                            defaultCurve = blendParams.m_Blend.BlendCurve;
                    }
                    else if (blendParams.m_To == kBlendFromAnyCameraLabel
                             && !string.IsNullOrEmpty(fromCameraName)
                             && blendParams.m_From == fromCameraName)
                    {
                        meToAny = blendParams.m_Blend.BlendCurve;
                    }
                }
            }

            
            
            if (anyToMe != null)
                return anyToMe;

            
            if (meToAny != null)
                return meToAny;

            return defaultCurve;
        }
    }
}
