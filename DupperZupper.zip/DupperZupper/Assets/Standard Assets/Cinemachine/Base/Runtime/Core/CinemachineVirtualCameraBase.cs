﻿using System;
using UnityEngine;

namespace Cinemachine
{
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    [SaveDuringPlay]
    public abstract class CinemachineVirtualCameraBase : MonoBehaviour, ICinemachineCamera
    {
        
        
        [HideInInspector, NoSaveDuringPlay]
        public Action CinemachineGUIDebuggerCallback = null;

        
        [HideInInspector, SerializeField, NoSaveDuringPlay]
        public string[] m_ExcludedPropertiesInInspector = new string[] { "m_Script" };

        
        [HideInInspector, SerializeField, NoSaveDuringPlay]
        public CinemachineCore.Stage[] m_LockStageInInspector;

        
        public int ValidatingStreamVersion 
        { 
            get { return m_OnValidateCalled ? m_ValidatingStreamVersion : CinemachineCore.kStreamingVersion; }
            private set { m_ValidatingStreamVersion = value; } 
        }
        private int m_ValidatingStreamVersion = 0;
        private bool m_OnValidateCalled = false;

        [HideInInspector, SerializeField, NoSaveDuringPlay]
        private int m_StreamingVersion;

        
        
        
        [NoSaveDuringPlay]
        [Tooltip("The priority will determine which camera becomes active based on the state of other cameras and this camera.  Higher numbers have greater priority.")]
        public int m_Priority = 10;

        
        
        
        
        
        
        public virtual void AddPostPipelineStageHook(OnPostPipelineStageDelegate d)
        {
            OnPostPipelineStage -= d;
            OnPostPipelineStage += d;
        }

        
        
        public virtual void RemovePostPipelineStageHook(OnPostPipelineStageDelegate d)
        {
            OnPostPipelineStage -= d;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        public delegate void OnPostPipelineStageDelegate(
            CinemachineVirtualCameraBase vcam, CinemachineCore.Stage stage,
            ref CameraState newState, float deltaTime);

        
        
        
        
        
        
        protected OnPostPipelineStageDelegate OnPostPipelineStage;

        
        
        
        
        protected void InvokePostPipelineStageCallback(
            CinemachineVirtualCameraBase vcam, CinemachineCore.Stage stage,
            ref CameraState newState, float deltaTime)
        {
            if (OnPostPipelineStage != null)
                OnPostPipelineStage(vcam, stage, ref newState, deltaTime);
            CinemachineVirtualCameraBase parent = ParentCamera as CinemachineVirtualCameraBase;
            if (parent != null)
                parent.InvokePostPipelineStageCallback(vcam, stage, ref newState, deltaTime);
        }

        
        
        public string Name { get { return name; } }

        
        public virtual string Description { get { return ""; }}

        
        
        public int Priority { get { return m_Priority; } set { m_Priority = value; } }

        
        public GameObject VirtualCameraGameObject
        {
            get
            {
                if (this == null)
                    return null; 
                return gameObject;
            }
        }

        
        
        public abstract CameraState State { get; }

        
        public virtual ICinemachineCamera LiveChildOrSelf { get { return this; } }

        
        
        
        
        public ICinemachineCamera ParentCamera
        {
            get
            {
                if (!mSlaveStatusUpdated || !Application.isPlaying)
                    UpdateSlaveStatus();
                return m_parentVcam;
            }
        }

        
        
        
        
        public virtual bool IsLiveChild(ICinemachineCamera vcam) { return false; }

        
        public abstract Transform LookAt { get; set; }

        
        public abstract Transform Follow { get; set; }

        
        public bool PreviousStateIsValid 
        { 
            get
            {
                if (LookAt != m_previousLookAtTarget)
                {
                    m_previousLookAtTarget = LookAt;
                    m_previousStateIsValid = false;
                }
                if (Follow != m_previousFollowTarget)
                {
                    m_previousFollowTarget = Follow;
                    m_previousStateIsValid = false;
                }
                return m_previousStateIsValid;
            }
            set
            {
                m_previousStateIsValid = value;
            }
        }
        private bool m_previousStateIsValid;
        private Transform m_previousLookAtTarget;
        private Transform m_previousFollowTarget;


        
        
        
        
        
        public abstract void UpdateCameraState(Vector3 worldUp, float deltaTime);

        
        
        
        
        
        public virtual void OnTransitionFromCamera(
            ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime) 
        {
            if (!gameObject.activeInHierarchy)
                PreviousStateIsValid = false;
        }

        
        protected virtual void Start()
        {
        }

        
        protected virtual void OnDestroy()
        {
            CinemachineCore.Instance.RemoveActiveCamera(this);
        }

        
        
        
        protected virtual void OnValidate()
        {
            m_OnValidateCalled = true;
            ValidatingStreamVersion = m_StreamingVersion;
            m_StreamingVersion = CinemachineCore.kStreamingVersion;
        }

        
        protected virtual void OnEnable()
        {
            
            var vcamComponents = GetComponents<CinemachineVirtualCameraBase>();
            for (int i = 0; i < vcamComponents.Length; ++i)
            {
                if (vcamComponents[i].enabled && vcamComponents[i] != this)
                {
                    Debug.LogError(Name
                        + " has multiple CinemachineVirtualCameraBase-derived components.  Disabling "
                        + GetType().Name + ".");
                    enabled = false;
                }
            }
            UpdateSlaveStatus();
            UpdateVcamPoolStatus();    
            PreviousStateIsValid = false;
        }

        
        protected virtual void OnDisable()
        {
            UpdateVcamPoolStatus();    
        }

        
        protected virtual void Update()
        {
            if (m_Priority != m_QueuePriority)
                UpdateVcamPoolStatus();
        }

        
        protected virtual void OnTransformParentChanged()
        {
            UpdateSlaveStatus();
            UpdateVcamPoolStatus();
        }

#if UNITY_EDITOR
        
        protected virtual void OnGUI()
        {
            if (CinemachineGUIDebuggerCallback != null)
                CinemachineGUIDebuggerCallback();
        }
#endif
        private bool mSlaveStatusUpdated = false;
        private CinemachineVirtualCameraBase m_parentVcam = null;

        private void UpdateSlaveStatus()
        {
            mSlaveStatusUpdated = true;
            m_parentVcam = null;
            Transform p = transform.parent;
            if (p != null)
                m_parentVcam = p.GetComponent<CinemachineVirtualCameraBase>();
        }

        
        
        
        
        protected Transform ResolveLookAt(Transform localLookAt)
        {
            Transform lookAt = localLookAt;
            if (lookAt == null && ParentCamera != null)
                lookAt = ParentCamera.LookAt; 
            return lookAt;
        }

        
        
        
        
        protected Transform ResolveFollow(Transform localFollow)
        {
            Transform follow = localFollow;
            if (follow == null && ParentCamera != null)
                follow = ParentCamera.Follow; 
            return follow;
        }

        private int m_QueuePriority = int.MaxValue;
        private void UpdateVcamPoolStatus()
        {
            m_QueuePriority = int.MaxValue;
            CinemachineCore.Instance.RemoveActiveCamera(this);
            CinemachineCore.Instance.RemoveChildCamera(this);
            if (m_parentVcam == null)
            {
                if (isActiveAndEnabled)
                {
                    CinemachineCore.Instance.AddActiveCamera(this);
                    m_QueuePriority = m_Priority;
                }
            }
            else
            {
                if (isActiveAndEnabled)
                    CinemachineCore.Instance.AddChildCamera(this);
            }
        }

        
        
        
        
        
        
        
        
        public void MoveToTopOfPrioritySubqueue()
        {
            UpdateVcamPoolStatus();
        }
    }
}
