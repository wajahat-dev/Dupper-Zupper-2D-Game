﻿using UnityEngine;

namespace Cinemachine
{
    
    
    
    
    [DocumentationSorting(23, DocumentationSortingAttribute.Level.UserRef)]
    [AddComponentMenu("")] 
    [RequireComponent(typeof(CinemachinePipeline))]
    [SaveDuringPlay]
    public class CinemachineHardLookAt : CinemachineComponentBase
    {
        
        public override bool IsValid { get { return enabled && LookAtTarget != null; } }

        
        
        public override CinemachineCore.Stage Stage { get { return CinemachineCore.Stage.Aim; } }

        
        
        
        
        public override void MutateCameraState(ref CameraState curState, float deltaTime)
        {
            if (IsValid && curState.HasLookAt)
            {
                Vector3 dir = (curState.ReferenceLookAt - curState.CorrectedPosition);
                if (dir.magnitude > Epsilon)
                {
                    if (Vector3.Cross(dir.normalized, curState.ReferenceUp).magnitude < Epsilon)
                        curState.RawOrientation = Quaternion.FromToRotation(Vector3.forward, dir);
                    else
                        curState.RawOrientation = Quaternion.LookRotation(dir, curState.ReferenceUp);
                }
            }
        }
    }
}

