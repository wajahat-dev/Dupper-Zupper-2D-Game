using UnityEngine;

namespace Cinemachine
{
    
    
    
    
    [DocumentationSorting(27, DocumentationSortingAttribute.Level.UserRef)]
    [AddComponentMenu("")] 
    [RequireComponent(typeof(CinemachinePipeline))]
    [SaveDuringPlay]
    public class CinemachineSameAsFollowObject : CinemachineComponentBase
    {
        
        public override bool IsValid { get { return enabled && FollowTarget != null; } }

        
        
        public override CinemachineCore.Stage Stage { get { return CinemachineCore.Stage.Aim; } }

        
        
        
        
        public override void MutateCameraState(ref CameraState curState, float deltaTime)
        {
            if (IsValid)
                curState.RawOrientation = FollowTarget.transform.rotation;
        }
    }
}

