using UnityEngine;
using UnityEngine.Serialization;

namespace Cinemachine
{
    
    
    
    
    
    
    
    
    
    
    [DocumentationSorting(8, DocumentationSortingAttribute.Level.UserRef)]
    [AddComponentMenu("")] 
    [RequireComponent(typeof(CinemachinePipeline))]
    [SaveDuringPlay]
    public class CinemachineBasicMultiChannelPerlin : CinemachineComponentBase
    {
        
        
        
        [HideInInspector]
        [Tooltip("The asset containing the Noise Profile.  Define the frequencies and amplitudes there to make a characteristic noise profile.  Make your own or just use one of the many presets.")]
        [FormerlySerializedAs("m_Definition")]
        public NoiseSettings m_NoiseProfile;

        
        
        
        [Tooltip("Gain to apply to the amplitudes defined in the NoiseSettings asset.  1 is normal.  Setting this to 0 completely mutes the noise.")]
        public float m_AmplitudeGain = 1f;

        
        
        
        [Tooltip("Scale factor to apply to the frequencies defined in the NoiseSettings asset.  1 is normal.  Larger magnitudes will make the noise shake more rapidly.")]
        public float m_FrequencyGain = 1f;

        
        public override bool IsValid { get { return enabled && m_NoiseProfile != null; } }

        
        
        public override CinemachineCore.Stage Stage { get { return CinemachineCore.Stage.Noise; } }

        
        
        
        
        
        public override void MutateCameraState(ref CameraState curState, float deltaTime)
        {
            if (!IsValid || deltaTime < 0)
                return;

            
            if (!mInitialized)
                Initialize();

            mNoiseTime += deltaTime * m_FrequencyGain;
            curState.PositionCorrection += curState.CorrectedOrientation * GetCombinedFilterResults(
                    m_NoiseProfile.PositionNoise, mNoiseTime, mNoiseOffsets) * m_AmplitudeGain;
            Quaternion rotNoise = Quaternion.Euler(GetCombinedFilterResults(
                        m_NoiseProfile.OrientationNoise, mNoiseTime, mNoiseOffsets) * m_AmplitudeGain);
            curState.OrientationCorrection = curState.OrientationCorrection * rotNoise;
            
        }

        private bool mInitialized = false;
        private float mNoiseTime = 0;
        private Vector3 mNoiseOffsets = Vector3.zero;

        void Initialize()
        {
            mInitialized = true;
            mNoiseTime = 0;
            mNoiseOffsets = new Vector3(
                    UnityEngine.Random.Range(-10000f, 10000f),
                    UnityEngine.Random.Range(-10000f, 10000f),
                    UnityEngine.Random.Range(-10000f, 10000f));
        }

        static Vector3 GetCombinedFilterResults(
            NoiseSettings.TransformNoiseParams[] noiseParams, float time, Vector3 noiseOffsets)
        {
            float xPos = 0f;
            float yPos = 0f;
            float zPos = 0f;
            if (noiseParams != null)
            {
                for (int i = 0; i < noiseParams.Length; ++i)
                {
                    NoiseSettings.TransformNoiseParams param = noiseParams[i];
                    Vector3 timeVal = new Vector3(param.X.Frequency, param.Y.Frequency, param.Z.Frequency) * time;
                    timeVal += noiseOffsets;

                    Vector3 noise = new Vector3(
                            Mathf.PerlinNoise(timeVal.x, 0f) - 0.5f,
                            Mathf.PerlinNoise(timeVal.y, 0f) - 0.5f,
                            Mathf.PerlinNoise(timeVal.z, 0f) - 0.5f);

                    xPos += noise.x * param.X.Amplitude;
                    yPos += noise.y * param.Y.Amplitude;
                    zPos += noise.z * param.Z.Amplitude;
                }
            }
            return new Vector3(xPos, yPos, zPos);
        }
    }
}
